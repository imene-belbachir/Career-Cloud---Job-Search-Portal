﻿using CareerCloud.DataAccessLayer;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.IO;
using CareerCloud.Pocos;

namespace CareerCloud.ADODataAccessLayer
{
    public class CompanyLocationRepository : IDataRepository<CompanyLocationPoco>
    {
        private readonly string _connectionString;

        public CompanyLocationRepository()
        {
            
            _connectionString = "Data Source=IMENE;Initial Catalog=JOB_PORTAL_DB;Integrated Security=True";
        }

        public void Add(params CompanyLocationPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                foreach (var item in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;

                    cmd.CommandText = "INSERT INTO Company_Locations (Id, Company, Country_Code, State_Province_Code, Street_Address, City_Town, Zip_Postal_Code) " +
                                    "VALUES (@Id, @Company, @CountryCode, @Province, @Street, @City, @PostalCode)";

                    cmd.Parameters.AddWithValue("@Id", item.Id);
                    cmd.Parameters.AddWithValue("@Company", item.Company);
                    cmd.Parameters.AddWithValue("@CountryCode", item.CountryCode);
                    cmd.Parameters.AddWithValue("@Province", item.Province);
                    cmd.Parameters.AddWithValue("@Street", item.Street);
                    cmd.Parameters.AddWithValue("@City", item.City);
                    cmd.Parameters.AddWithValue("@PostalCode", item.PostalCode);
                  

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public IList<CompanyLocationPoco> GetAll(params Expression<Func<CompanyLocationPoco, object>>[] navigationProperties)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Company_Locations", connection);
                SqlDataReader reader = cmd.ExecuteReader();

                var companyLocationList = new List<CompanyLocationPoco>();

                while (reader.Read())
                {
                    var companyLocation = new CompanyLocationPoco
                    {
                        Id = (Guid)reader["Id"],
                        Company = (Guid)reader["Company"],
                        CountryCode = (string)reader["Country_Code"],
                        Province = reader["State_Province_Code"] as string,
                        Street = reader["Street_Address"] as string,
                        City = reader["City_Town"] as string,
                        PostalCode = reader["Zip_Postal_Code"] as string,
                        TimeStamp = (byte[])reader["Time_Stamp"]
                    };

                    companyLocationList.Add(companyLocation);
                }

                reader.Close();
                return companyLocationList;
            }
        }

        public void Remove(params CompanyLocationPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                foreach (var poco in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DELETE FROM Company_Locations WHERE Id = @Id";
                    cmd.Parameters.AddWithValue("@Id", poco.Id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Update(params CompanyLocationPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                foreach (var poco in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;

                    cmd.CommandText = "UPDATE Company_Locations " +
                                    "SET Company = @Company, Country_Code = @CountryCode, State_Province_Code = @Province, Street_Address = @Street, City_Town = @City, Zip_Postal_Code = @PostalCode "  +
                                    "WHERE Id = @Id";

                    cmd.Parameters.AddWithValue("@Id", poco.Id);
                    cmd.Parameters.AddWithValue("@Company", poco.Company);
                    cmd.Parameters.AddWithValue("@CountryCode", poco.CountryCode);
                    cmd.Parameters.AddWithValue("@Province", poco.Province );
                    cmd.Parameters.AddWithValue("@Street", poco.Street );
                    cmd.Parameters.AddWithValue("@City", poco.City );
                    cmd.Parameters.AddWithValue("@PostalCode", poco.PostalCode );

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public CompanyLocationPoco GetSingle(Expression<Func<CompanyLocationPoco, bool>> where, params Expression<Func<CompanyLocationPoco, object>>[] navigationProperties)
        {
            IQueryable<CompanyLocationPoco> pocos = GetAll().AsQueryable();
            return pocos.Where(where.Compile()).FirstOrDefault();
        }

        public IList<CompanyLocationPoco> GetList(Expression<Func<CompanyLocationPoco, bool>> where, params Expression<Func<CompanyLocationPoco, object>>[] navigationProperties)
        {
            throw new NotImplementedException();
        }

        public void CallStoredProc(string name, params Tuple<string, string>[] parameters)
        {
            throw new NotImplementedException();
        }
    }
}
