﻿using CareerCloud.DataAccessLayer;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.IO;
using CareerCloud.Pocos;

namespace CareerCloud.ADODataAccessLayer
{
    public class ApplicantWorkHistoryRepository : IDataRepository<ApplicantWorkHistoryPoco>
    {
        private readonly string _connectionString;

        public ApplicantWorkHistoryRepository()
        {
            _connectionString = "Data Source=IMENE;Initial Catalog=JOB_PORTAL_DB;Integrated Security=True";
        }

        public void Add(params ApplicantWorkHistoryPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                foreach (var item in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;

                    cmd.CommandText = "INSERT INTO Applicant_Work_History (Id, Applicant, Company_Name, Country_Code, Location, Job_Title, Job_Description, Start_Month, Start_Year, End_Month, End_Year) " +
                                    "VALUES (@Id, @Applicant, @CompanyName, @CountryCode, @Location, @JobTitle, @JobDescription, @StartMonth, @StartYear, @EndMonth, @EndYear)";

                    cmd.Parameters.AddWithValue("@Id", item.Id);
                    cmd.Parameters.AddWithValue("@Applicant", item.Applicant);
                    cmd.Parameters.AddWithValue("@CompanyName", item.CompanyName);
                    cmd.Parameters.AddWithValue("@CountryCode", item.CountryCode);
                    cmd.Parameters.AddWithValue("@Location", item.Location);
                    cmd.Parameters.AddWithValue("@JobTitle", item.JobTitle);
                    cmd.Parameters.AddWithValue("@JobDescription", item.JobDescription);
                    cmd.Parameters.AddWithValue("@StartMonth", item.StartMonth);
                    cmd.Parameters.AddWithValue("@StartYear", item.StartYear);
                    cmd.Parameters.AddWithValue("@EndMonth", item.EndMonth);
                    cmd.Parameters.AddWithValue("@EndYear", item.EndYear);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public IList<ApplicantWorkHistoryPoco> GetAll(params Expression<Func<ApplicantWorkHistoryPoco, object>>[] navigationProperties)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Applicant_Work_History", connection);
                SqlDataReader reader = cmd.ExecuteReader();

                var workHistoryList = new List<ApplicantWorkHistoryPoco>();

                while (reader.Read())
                {
                    var workHistory = new ApplicantWorkHistoryPoco
                    {
                        Id = (Guid)reader["Id"],
                        Applicant = (Guid)reader["Applicant"],
                        CompanyName = (string)reader["Company_Name"],
                        CountryCode = (string)reader["Country_Code"],
                        Location = (string)reader["Location"],
                        JobTitle = (string)reader["Job_Title"],
                        JobDescription = (string)reader["Job_Description"],
                        StartMonth = (short)reader["Start_Month"],
                        StartYear = (int)reader["Start_Year"],
                        EndMonth = (short)reader["End_Month"],
                        EndYear = (int)reader["End_Year"],
                        TimeStamp = (byte[])reader["Time_Stamp"]
                    };

                    workHistoryList.Add(workHistory);
                }

                reader.Close();
                return workHistoryList;
            }
        }

        public void Remove(params ApplicantWorkHistoryPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                foreach (var poco in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DELETE FROM Applicant_Work_History WHERE Id = @Id";
                    cmd.Parameters.AddWithValue("@Id", poco.Id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Update(params ApplicantWorkHistoryPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                foreach (var poco in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;

                     cmd.CommandText = "UPDATE Applicant_Work_History " +
                                    "SET Applicant = @Applicant, Company_Name = @CompanyName, Country_Code = @CountryCode, Location = @Location, Job_Title = @JobTitle , Job_Description = @JobDescription, Start_Month = @StartMonth, Start_Year = @StartYear, End_Month = @EndMonth, End_Year = @EndYear "  +
                                   "WHERE Id = @Id";

                     cmd.Parameters.AddWithValue("@Id", poco.Id);
                     cmd.Parameters.AddWithValue("@Applicant", poco.Applicant);
                     cmd.Parameters.AddWithValue("@CompanyName", poco.CompanyName);
                     cmd.Parameters.AddWithValue("@CountryCode", poco.CountryCode);
                     cmd.Parameters.AddWithValue("@Location", poco.Location);
                     cmd.Parameters.AddWithValue("@JobTitle", poco.JobTitle);
                    cmd.Parameters.AddWithValue("@JobDescription", poco.JobDescription); 
                      cmd.Parameters.AddWithValue("@StartMonth", poco.StartMonth); 
                      cmd.Parameters.AddWithValue("@StartYear", poco.StartYear);
                      cmd.Parameters.AddWithValue("@EndMonth", poco.EndMonth); 
                     cmd.Parameters.AddWithValue("@EndYear", poco.EndYear); 

                     
                  

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public ApplicantWorkHistoryPoco GetSingle(Expression<Func<ApplicantWorkHistoryPoco, bool>> where, params Expression<Func<ApplicantWorkHistoryPoco, object>>[] navigationProperties)
        {
            IQueryable<ApplicantWorkHistoryPoco> pocos = GetAll().AsQueryable();
            return pocos.Where(where.Compile()).FirstOrDefault();
        }

        public IList<ApplicantWorkHistoryPoco> GetList(Expression<Func<ApplicantWorkHistoryPoco, bool>> where, params Expression<Func<ApplicantWorkHistoryPoco, object>>[] navigationProperties)
        {
            throw new NotImplementedException();
        }

        public void CallStoredProc(string name, params Tuple<string, string>[] parameters)
        {
            throw new NotImplementedException();
        }
    }
}
