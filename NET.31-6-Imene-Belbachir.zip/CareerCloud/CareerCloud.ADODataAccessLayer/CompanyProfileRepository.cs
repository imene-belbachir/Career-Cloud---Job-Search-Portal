﻿
using CareerCloud.DataAccessLayer;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.IO;
using CareerCloud.Pocos;

namespace CareerCloud.ADODataAccessLayer
{
    public class CompanyProfileRepository : IDataRepository<CompanyProfilePoco>
    {
        private readonly string _connectionString;

        public CompanyProfileRepository()
        {
           
            _connectionString = "Data Source=IMENE;Initial Catalog=JOB_PORTAL_DB;Integrated Security=True";
        }

        public void Add(params CompanyProfilePoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                foreach (var item in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;

                    cmd.CommandText = "INSERT INTO Company_Profiles (Id, Registration_Date, Company_Website, Contact_Phone, Contact_Name, Company_Logo) " +
                                    "VALUES (@Id, @RegistrationDate, @CompanyWebsite, @ContactPhone, @ContactName, @CompanyLogo)";

                    cmd.Parameters.AddWithValue("@Id", item.Id);
                    cmd.Parameters.AddWithValue("@RegistrationDate", item.RegistrationDate);
                    cmd.Parameters.AddWithValue("@CompanyWebsite", item.CompanyWebsite ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@ContactPhone", item.ContactPhone);
                    cmd.Parameters.AddWithValue("@ContactName", item.ContactName ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@CompanyLogo", item.CompanyLogo ?? (object)DBNull.Value);
                   

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public IList<CompanyProfilePoco> GetAll(params Expression<Func<CompanyProfilePoco, object>>[] navigationProperties)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Company_Profiles", connection);
                SqlDataReader reader = cmd.ExecuteReader();

                var companyProfileList = new List<CompanyProfilePoco>();

                while (reader.Read())
                {
                    var companyProfile = new CompanyProfilePoco
                    {
                        Id = (Guid)reader["Id"],
                        RegistrationDate = (DateTime)reader["Registration_Date"],
                        CompanyWebsite = reader["Company_Website"] as string,
                        ContactPhone = (string)reader["Contact_Phone"],
                        ContactName = reader["Contact_Name"] as string,
                        CompanyLogo = reader["Company_Logo"] as byte[],
                        TimeStamp = reader["Time_Stamp"] as byte[]
                    };

                    companyProfileList.Add(companyProfile);
                }

                reader.Close();
                return companyProfileList;
            }
        }

        public void Remove(params CompanyProfilePoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                foreach (var poco in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DELETE FROM Company_Profiles WHERE Id = @Id";
                    cmd.Parameters.AddWithValue("@Id", poco.Id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Update(params CompanyProfilePoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                foreach (var poco in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;

                    cmd.CommandText = "UPDATE Company_Profiles " +
                                    "SET Registration_Date = @RegistrationDate, Company_Website = @CompanyWebsite, Contact_Phone = @ContactPhone, Contact_Name = @ContactName, Company_Logo = @CompanyLogo " +
                                    "WHERE Id = @Id";

                    cmd.Parameters.AddWithValue("@Id", poco.Id);
                    cmd.Parameters.AddWithValue("@RegistrationDate", poco.RegistrationDate);
                    cmd.Parameters.AddWithValue("@CompanyWebsite", poco.CompanyWebsite ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@ContactPhone", poco.ContactPhone);
                    cmd.Parameters.AddWithValue("@ContactName", poco.ContactName ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@CompanyLogo", poco.CompanyLogo ?? (object)DBNull.Value);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public CompanyProfilePoco GetSingle(Expression<Func<CompanyProfilePoco, bool>> where, params Expression<Func<CompanyProfilePoco, object>>[] navigationProperties)
        {
            IQueryable<CompanyProfilePoco> pocos = GetAll().AsQueryable();
            return pocos.Where(where.Compile()).FirstOrDefault();
        }

        public IList<CompanyProfilePoco> GetList(Expression<Func<CompanyProfilePoco, bool>> where, params Expression<Func<CompanyProfilePoco, object>>[] navigationProperties)
        {
            throw new NotImplementedException();
        }

        public void CallStoredProc(string name, params Tuple<string, string>[] parameters)
        {
            throw new NotImplementedException();
        }
    }
}
