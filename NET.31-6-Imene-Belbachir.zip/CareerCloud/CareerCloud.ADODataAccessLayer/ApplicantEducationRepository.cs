﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using CareerCloud.DataAccessLayer;
using CareerCloud.Pocos;

namespace CareerCloud.ADODataAccessLayer
{
    public class ApplicantEducationRepository : IDataRepository<ApplicantEducationPoco>
    {
        private readonly string _connection;

        private readonly SqlCommand _cmd;

        public ApplicantEducationRepository()
        {
            _connection = "Data Source=IMENE;Initial Catalog=JOB_PORTAL_DB;Integrated Security=True";

        }

       
        public void Add(params ApplicantEducationPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                connection.Open();

                foreach (var item in items)
                {
                    SqlCommand cmd = connection.CreateCommand();
                    cmd.CommandText = "INSERT INTO Applicant_Educations (Id, Applicant, Major, Certificate_Diploma, Start_Date, Completion_Date, Completion_Percent) " +
                                    "VALUES (@Id, @Applicant, @Major, @CertificateDiploma, @Start_Date, @CompletionDate, @CompletionPercent)";

                    cmd.Parameters.AddWithValue("@Id", item.Id);
                    cmd.Parameters.AddWithValue("@Applicant", item.Applicant);
                    cmd.Parameters.AddWithValue("@Major", item.Major);
                    cmd.Parameters.AddWithValue("@CertificateDiploma", item.CertificateDiploma);
                    cmd.Parameters.AddWithValue("@Start_Date", item.StartDate);
                    cmd.Parameters.AddWithValue("@CompletionDate", item.CompletionDate);
                    cmd.Parameters.AddWithValue("@CompletionPercent", item.CompletionPercent);

                    cmd.ExecuteNonQuery();
                }
            }
        }

       
        public IList<ApplicantEducationPoco> GetAll(params Expression<Func<ApplicantEducationPoco, object>>[] navigationProperties)
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                connection.Open();
                using (SqlCommand cmd = connection.CreateCommand())
                {
                    cmd.CommandText = "SELECT * FROM Applicant_Educations";
                    SqlDataReader reader = cmd.ExecuteReader();

                    var educationList = new List<ApplicantEducationPoco>();

                    while (reader.Read())
                    {
                        var education = new ApplicantEducationPoco
                        {
                            Id = (Guid)reader["Id"],
                            Applicant = (Guid)reader["Applicant"],
                            Major = (string)reader["Major"],
                            CertificateDiploma = reader["Certificate_Diploma"] as string,
                            StartDate = reader["Start_Date"] as DateTime?,
                            CompletionDate = reader["Completion_Date"] as DateTime?,
                            CompletionPercent = reader["Completion_Percent"] as byte?,
                            TimeStamp = (byte[])reader["Time_Stamp"]
                        };

                        educationList.Add(education);
                    }

                    reader.Close();
                    return educationList;
                }
            }
        }


        
        public void Remove(params ApplicantEducationPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                connection.Open();
                using (SqlCommand cmd = connection.CreateCommand())
                {
                    cmd.CommandText = "DELETE FROM Applicant_Educations WHERE Id = @Id";
                    SqlParameter param = cmd.Parameters.Add("@Id", SqlDbType.UniqueIdentifier);

                    foreach (var poco in items)
                    {
                        param.Value = poco.Id;
                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }


       
        public void Update(params ApplicantEducationPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                connection.Open();
                using (SqlCommand cmd = connection.CreateCommand())
                {
                    foreach (var poco in items)
                    {
                        cmd.CommandText = "UPDATE Applicant_Educations " +
                                          "SET Applicant = @Applicant, Major = @Major, Certificate_Diploma = @CertificateDiploma, Start_Date = @Start_Date, Completion_Date = @CompletionDate, Completion_Percent = @CompletionPercent " +
                                          "WHERE Id = @Id";

                        cmd.Parameters.AddWithValue("@Id", poco.Id);
                        cmd.Parameters.AddWithValue("@Applicant", poco.Applicant);
                        cmd.Parameters.AddWithValue("@Major", poco.Major);
                        cmd.Parameters.AddWithValue("@CertificateDiploma", poco.CertificateDiploma);
                        cmd.Parameters.AddWithValue("@Start_Date", poco.StartDate);
                        cmd.Parameters.AddWithValue("@CompletionDate", poco.CompletionDate);
                        cmd.Parameters.AddWithValue("@CompletionPercent", poco.CompletionPercent);

                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        public ApplicantEducationPoco GetSingle(Expression<Func<ApplicantEducationPoco, bool>> where, params Expression<Func<ApplicantEducationPoco, object>>[] navigationProperties)
        {
            IQueryable<ApplicantEducationPoco> pocos = GetAll().AsQueryable();
            return pocos.Where(where.Compile()).FirstOrDefault();
        }

        public IList<ApplicantEducationPoco> GetList(Expression<Func<ApplicantEducationPoco, bool>> where, params Expression<Func<ApplicantEducationPoco, object>>[] navigationProperties)
        {
            throw new NotImplementedException();
        }

        public void CallStoredProc(string name, params Tuple<string, string>[] parameters)
        {
            throw new NotImplementedException();
        }
    }
}
