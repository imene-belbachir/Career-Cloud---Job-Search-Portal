﻿using CareerCloud.DataAccessLayer;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.IO;
using CareerCloud.Pocos;

namespace CareerCloud.ADODataAccessLayer
{
    public class CompanyJobDescriptionRepository : IDataRepository<CompanyJobDescriptionPoco>
    {
        private readonly string _connectionString;

        public CompanyJobDescriptionRepository()
        {
            
            _connectionString = "Data Source=IMENE;Initial Catalog=JOB_PORTAL_DB;Integrated Security=True";
        }

        public void Add(params CompanyJobDescriptionPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                foreach (var item in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;

                    cmd.CommandText = "INSERT INTO Company_Jobs_Descriptions (Id, Job, Job_Name, Job_Descriptions) " +
                                    "VALUES (@Id, @Job, @JobName, @JobDescriptions)";

                    cmd.Parameters.AddWithValue("@Id", item.Id);
                    cmd.Parameters.AddWithValue("@Job", item.Job);
                    cmd.Parameters.AddWithValue("@JobName", item.JobName);
                    cmd.Parameters.AddWithValue("@JobDescriptions", item.JobDescriptions);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public IList<CompanyJobDescriptionPoco> GetAll(params Expression<Func<CompanyJobDescriptionPoco, object>>[] navigationProperties)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Company_Jobs_Descriptions", connection);
                SqlDataReader reader = cmd.ExecuteReader();

                var companyJobDescriptionList = new List<CompanyJobDescriptionPoco>();

                while (reader.Read())
                {
                    var companyJobDescription = new CompanyJobDescriptionPoco
                    {
                        Id = (Guid)reader["Id"],
                        Job = (Guid)reader["Job"],
                        JobName = reader["Job_Name"] as string,
                        JobDescriptions = reader["Job_Descriptions"] as string,
                        TimeStamp = reader["Time_Stamp"] as byte[]
                    };

                    companyJobDescriptionList.Add(companyJobDescription);
                }

                reader.Close();
                return companyJobDescriptionList;
            }
        }

        public void Remove(params CompanyJobDescriptionPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                foreach (var poco in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DELETE FROM Company_Jobs_Descriptions WHERE Id = @Id";
                    cmd.Parameters.AddWithValue("@Id", poco.Id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Update(params CompanyJobDescriptionPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                foreach (var poco in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;

                    cmd.CommandText = "UPDATE Company_Jobs_Descriptions " +
                                    "SET Job = @Job, Job_Name = @JobName, Job_Descriptions = @JobDescriptions " +
                                    "WHERE Id = @Id";

                    cmd.Parameters.AddWithValue("@Id", poco.Id);
                    cmd.Parameters.AddWithValue("@Job", poco.Job);
                    cmd.Parameters.AddWithValue("@JobName", poco.JobName);
                    cmd.Parameters.AddWithValue("@JobDescriptions", poco.JobDescriptions);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public CompanyJobDescriptionPoco GetSingle(Expression<Func<CompanyJobDescriptionPoco, bool>> where, params Expression<Func<CompanyJobDescriptionPoco, object>>[] navigationProperties)
        {
            IQueryable<CompanyJobDescriptionPoco> pocos = GetAll().AsQueryable();
            return pocos.Where(where.Compile()).FirstOrDefault();
        }

        public IList<CompanyJobDescriptionPoco> GetList(Expression<Func<CompanyJobDescriptionPoco, bool>> where, params Expression<Func<CompanyJobDescriptionPoco, object>>[] navigationProperties)
        {
            throw new NotImplementedException();
        }

        public void CallStoredProc(string name, params Tuple<string, string>[] parameters)
        {
            throw new NotImplementedException();
        }
    }
}
