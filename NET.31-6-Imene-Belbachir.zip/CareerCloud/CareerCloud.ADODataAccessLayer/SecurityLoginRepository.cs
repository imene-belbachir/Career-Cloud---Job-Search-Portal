﻿using CareerCloud.DataAccessLayer;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.IO;
using CareerCloud.Pocos;

namespace CareerCloud.ADODataAccessLayer
{
    public class SecurityLoginRepository : IDataRepository<SecurityLoginPoco>
    {
        private readonly string _connectionString;

        public SecurityLoginRepository()
        {
           
            _connectionString = "Data Source=IMENE;Initial Catalog=JOB_PORTAL_DB;Integrated Security=True";
        }

        public void Add(params SecurityLoginPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                foreach (var item in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;

                    cmd.CommandText = "INSERT INTO Security_Logins (Id, Login, Password, Created_Date, Password_Update_Date, " +
                                    "Agreement_Accepted_Date, Is_Locked, Is_Inactive, Email_Address, Phone_Number, Full_Name, " +
                                    "Force_Change_Password, Prefferred_Language) " +
                                    "VALUES (@Id, @Login, @Password, @Created, @PasswordUpdate, @AgreementAccepted, @IsLocked, " +
                                    "@IsInactive, @EmailAddress, @PhoneNumber, @FullName, @ForceChangePassword, @PrefferredLanguage)";

                    cmd.Parameters.AddWithValue("@Id", item.Id);
                    cmd.Parameters.AddWithValue("@Login", item.Login);
                    cmd.Parameters.AddWithValue("@Password", item.Password);
                    cmd.Parameters.AddWithValue("@Created", item.Created);
                    cmd.Parameters.AddWithValue("@PasswordUpdate", item.PasswordUpdate );
                    cmd.Parameters.AddWithValue("@AgreementAccepted", item.AgreementAccepted );
                    cmd.Parameters.AddWithValue("@IsLocked", item.IsLocked);
                    cmd.Parameters.AddWithValue("@IsInactive", item.IsInactive);
                    cmd.Parameters.AddWithValue("@EmailAddress", item.EmailAddress);
                    cmd.Parameters.AddWithValue("@PhoneNumber", item.PhoneNumber );
                    cmd.Parameters.AddWithValue("@FullName", item.FullName );
                    cmd.Parameters.AddWithValue("@ForceChangePassword", item.ForceChangePassword);
                    cmd.Parameters.AddWithValue("@PrefferredLanguage", item.PrefferredLanguage );
                   

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public IList<SecurityLoginPoco> GetAll(params Expression<Func<SecurityLoginPoco, object>>[] navigationProperties)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Security_Logins", connection);
                SqlDataReader reader = cmd.ExecuteReader();

                var securityLoginList = new List<SecurityLoginPoco>();

                while (reader.Read())
                {
                    var securityLogin = new SecurityLoginPoco
                    {
                        Id = (Guid)reader["Id"],
                        Login = (string)reader["Login"],
                        Password = (string)reader["Password"],
                        Created = (DateTime)reader["Created_Date"],
                        PasswordUpdate = reader["Password_Update_Date"] as DateTime?,
                        AgreementAccepted = reader["Agreement_Accepted_Date"] as DateTime?,
                        IsLocked = (bool)reader["Is_Locked"],
                        IsInactive = (bool)reader["Is_Inactive"],
                        EmailAddress = (string)reader["Email_Address"],
                        PhoneNumber = reader["Phone_Number"] as string,
                        FullName = reader["Full_Name"] as string,
                        ForceChangePassword = (bool)reader["Force_Change_Password"],
                        PrefferredLanguage = reader["Prefferred_Language"] as string,
                        TimeStamp = (byte[])reader["Time_Stamp"]
                    };

                    securityLoginList.Add(securityLogin);
                }

                reader.Close();
                return securityLoginList;
            }
        }

        public void Remove(params SecurityLoginPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                foreach (var poco in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DELETE FROM Security_Logins WHERE Id = @Id";
                    cmd.Parameters.AddWithValue("@Id", poco.Id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Update(params SecurityLoginPoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                foreach (var poco in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;

                    cmd.CommandText = "UPDATE Security_Logins " +
                                    "SET Login = @Login, Password = @Password, Created_Date = @Created, Password_Update_Date = @PasswordUpdate, " +
                                    "Agreement_Accepted_Date = @AgreementAccepted, Is_Locked = @IsLocked, Is_Inactive = @IsInactive, " +
                                    "Email_Address = @EmailAddress, Phone_Number = @PhoneNumber, Full_Name = @FullName, " +
                                    "Force_Change_Password = @ForceChangePassword, Prefferred_Language = @PrefferredLanguage " +
                                    "WHERE Id = @Id";

                    cmd.Parameters.AddWithValue("@Id", poco.Id);
                    cmd.Parameters.AddWithValue("@Login", poco.Login);
                    cmd.Parameters.AddWithValue("@Password", poco.Password);
                    cmd.Parameters.AddWithValue("@Created", poco.Created);
                    cmd.Parameters.AddWithValue("@PasswordUpdate", poco.PasswordUpdate );
                    cmd.Parameters.AddWithValue("@AgreementAccepted", poco.AgreementAccepted );
                    cmd.Parameters.AddWithValue("@IsLocked", poco.IsLocked);
                    cmd.Parameters.AddWithValue("@IsInactive", poco.IsInactive);
                    cmd.Parameters.AddWithValue("@EmailAddress", poco.EmailAddress);
                    cmd.Parameters.AddWithValue("@PhoneNumber", poco.PhoneNumber);
                    cmd.Parameters.AddWithValue("@FullName", poco.FullName );
                    cmd.Parameters.AddWithValue("@ForceChangePassword", poco.ForceChangePassword);
                    cmd.Parameters.AddWithValue("@PrefferredLanguage", poco.PrefferredLanguage);
                   

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public SecurityLoginPoco GetSingle(Expression<Func<SecurityLoginPoco, bool>> where, params Expression<Func<SecurityLoginPoco, object>>[] navigationProperties)
        {
            IQueryable<SecurityLoginPoco> pocos = GetAll().AsQueryable();
            return pocos.Where(where.Compile()).FirstOrDefault();
        }

        public IList<SecurityLoginPoco> GetList(Expression<Func<SecurityLoginPoco, bool>> where, params Expression<Func<SecurityLoginPoco, object>>[] navigationProperties)
        {
            throw new NotImplementedException();
        }

        public void CallStoredProc(string name, params Tuple<string, string>[] parameters)
        {
            throw new NotImplementedException();
        }
    }
}

