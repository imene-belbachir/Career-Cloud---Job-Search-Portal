﻿
using CareerCloud.DataAccessLayer;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.IO;
using CareerCloud.Pocos;

namespace CareerCloud.ADODataAccessLayer
{
    public class ApplicantProfileRepository : IDataRepository<ApplicantProfilePoco>
    {
        private readonly string _connectionString;

        public ApplicantProfileRepository()
        {

            _connectionString = "Data Source=IMENE;Initial Catalog=JOB_PORTAL_DB;Integrated Security=True"; ;
        }

        public void Add(params ApplicantProfilePoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                foreach (var item in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;

                    cmd.CommandText = "INSERT INTO Applicant_Profiles (Id, Login, Current_Salary, Current_Rate, Currency, Country_Code, State_Province_Code, Street_Address, City_Town, Zip_Postal_Code) " +
                                    "VALUES (@Id, @Login, @CurrentSalary, @CurrentRate, @Currency, @Country, @Province, @Street, @City, @PostalCode)";

                    cmd.Parameters.AddWithValue("@Id", item.Id);
                    cmd.Parameters.AddWithValue("@Login", item.Login);
                    cmd.Parameters.AddWithValue("@CurrentSalary", item.CurrentSalary);
                    cmd.Parameters.AddWithValue("@CurrentRate", item.CurrentRate);
                    cmd.Parameters.AddWithValue("@Currency", item.Currency);
                    cmd.Parameters.AddWithValue("@Country", item.Country);
                    cmd.Parameters.AddWithValue("@Province", item.Province);
                    cmd.Parameters.AddWithValue("@Street", item.Street);
                    cmd.Parameters.AddWithValue("@City", item.City);
                    cmd.Parameters.AddWithValue("@PostalCode", item.PostalCode);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public IList<ApplicantProfilePoco> GetAll(params Expression<Func<ApplicantProfilePoco, object>>[] navigationProperties)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Applicant_Profiles", connection);
                SqlDataReader reader = cmd.ExecuteReader();

                var profileList = new List<ApplicantProfilePoco>();

                while (reader.Read())
                {
                    var profile = new ApplicantProfilePoco
                    {
                        Id = (Guid)reader["Id"],
                        Login = (Guid)reader["Login"],
                        CurrentSalary = reader["Current_Salary"] as decimal?,
                        CurrentRate = reader["Current_Rate"] as decimal?,
                        Currency = (string)reader["Currency"],
                        Country = reader["Country_Code"] as string,
                        Province = reader["State_Province_Code"] as string,
                        Street = reader["Street_Address"] as string,
                        City = (string)reader["City_Town"],
                        PostalCode = (string)reader["Zip_Postal_Code"],
                        TimeStamp = (byte[])reader["Time_Stamp"]
                    };

                    profileList.Add(profile);
                }

                reader.Close();
                return profileList;
            }
        }

        public void Remove(params ApplicantProfilePoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                foreach (var poco in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DELETE FROM Applicant_Profiles WHERE Id = @Id";
                    cmd.Parameters.AddWithValue("@Id", poco.Id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Update(params ApplicantProfilePoco[] items)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                foreach (var poco in items)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "UPDATE Applicant_Profiles " +
                                      "SET Login = @Login, Current_Salary = @CurrentSalary, Current_Rate = @CurrentRate, Currency = @Currency, Country_Code = @Country, State_Province_Code = @Province, Street_Address = @Street, City_Town = @City, Zip_Postal_Code = @PostalCode " +
                                      "WHERE Id = @Id";

                    cmd.Parameters.AddWithValue("@Id", poco.Id);
                    cmd.Parameters.AddWithValue("@Login", poco.Login);
                    cmd.Parameters.AddWithValue("@CurrentSalary", poco.CurrentSalary);
                    cmd.Parameters.AddWithValue("@CurrentRate", poco.CurrentRate);
                    cmd.Parameters.AddWithValue("@Currency", poco.Currency);
                    cmd.Parameters.AddWithValue("@Country", poco.Country);
                    cmd.Parameters.AddWithValue("@Province", poco.Province);
                    cmd.Parameters.AddWithValue("@Street", poco.Street);
                    cmd.Parameters.AddWithValue("@City", poco.City);
                    cmd.Parameters.AddWithValue("@PostalCode", poco.PostalCode);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public ApplicantProfilePoco GetSingle(Expression<Func<ApplicantProfilePoco, bool>> where, params Expression<Func<ApplicantProfilePoco, object>>[] navigationProperties)
        {
            IQueryable<ApplicantProfilePoco> pocos = GetAll().AsQueryable();
            return pocos.Where(where.Compile()).FirstOrDefault();
        }

        public IList<ApplicantProfilePoco> GetList(Expression<Func<ApplicantProfilePoco, bool>> where, params Expression<Func<ApplicantProfilePoco, object>>[] navigationProperties)
        {
            throw new NotImplementedException();
        }

        public void CallStoredProc(string name, params Tuple<string, string>[] parameters)
        {
            throw new NotImplementedException();
        }
    }
}

