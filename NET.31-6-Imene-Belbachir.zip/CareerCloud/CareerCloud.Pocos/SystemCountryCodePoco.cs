﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareerCloud.Pocos
{
    [Table("System_Country_Codes")]

    public class SystemCountryCodePoco : IPoco
       {
        

        [Key]
           public string Code { get; set; } = null!;
           [Column("Name")]
           public string Name { get; set; } = null!;

           public virtual ICollection<ApplicantProfilePoco> ApplicantProfiles { get; } = new List<ApplicantProfilePoco>();

           public virtual ICollection<ApplicantWorkHistoryPoco> ApplicantWorkHistories { get; } = new List<ApplicantWorkHistoryPoco>();
        Guid IPoco.Id { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

    }
   }