﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace CareerCloud.Pocos
{
    [Table("Applicant_Profiles")]

    public class ApplicantProfilePoco: IPoco
    {


        [Key]
        public Guid Id { get; set; }
        [Column("Login")]
        public Guid Login { get; set; }
        [Column("Current_Salary")]
        public decimal? CurrentSalary { get; set; }
        [Column("Current_Rate")]
        public decimal? CurrentRate { get; set; }
        [Column("Currency")]
        public string? Currency { get; set; }
        [Column("Country_Code")]
        //  public string? CountryCode { get; set; }
        public string? Country { get; set; }
        [Column("State_Province_Code")]
        //public string? StateProvinceCode { get; set; }
        public string? Province{ get; set; }
        [Column("Street_Address")]
        //public string? StreetAddress { get; set; }
        public string? Street { get; set; }
        [Column("City_Town")]
        public string? City { get; set; }
        [Column("Zip_Postal_Code")]
        public string? PostalCode { get; set; }
        [Column("Time_Stamp")]
        public byte[] TimeStamp { get; set; } = null!;

        public virtual ICollection<ApplicantEducationPoco> ApplicantEducations { get; } = new List<ApplicantEducationPoco>();

        public virtual ICollection<ApplicantJobApplicationPoco> ApplicantJobApplications { get; } = new List<ApplicantJobApplicationPoco>();

        public virtual ICollection<ApplicantResumePoco> ApplicantResumes { get; } = new List<ApplicantResumePoco>();

        public virtual ICollection<ApplicantSkillPoco> ApplicantSkills { get; } = new List<ApplicantSkillPoco>();

        public virtual ICollection<ApplicantWorkHistoryPoco> ApplicantWorkHistorys { get; } = new List<ApplicantWorkHistoryPoco>();

        public virtual SystemCountryCodePoco? SystemCountryCode { get; set; }

        public virtual SecurityLoginPoco LoginNavigation { get; set; } = null!;


    }
}
