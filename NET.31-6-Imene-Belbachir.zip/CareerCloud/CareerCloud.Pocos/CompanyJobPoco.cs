﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;


namespace CareerCloud.Pocos
{
    [Table("Company_Jobs")]

    public class CompanyJobPoco:IPoco
    {
        [Key]
        public Guid Id { get; set; }
        [Column("Company")]
        public Guid Company { get; set; }
        [Column("Profile_Created")]
        public DateTime ProfileCreated { get; set; }
        [Column("Is_Inactive")]
        public bool IsInactive { get; set; }
        [Column("Is_Company_Hidden")]
        public bool IsCompanyHidden { get; set; }
        [Column("Time_Stamp")]
        public byte[]? TimeStamp { get; set; }
        public virtual ICollection<ApplicantJobApplicationPoco> ApplicantJobApplications { get; } = new List<ApplicantJobApplicationPoco>();

        public virtual ICollection<CompanyJobEducationPoco> CompanyJobEducations { get; } = new List<CompanyJobEducationPoco>();

        public virtual ICollection<CompanyJobSkillPoco> CompanyJobSkills { get; } = new List<CompanyJobSkillPoco>();

        public virtual ICollection<CompanyJobDescriptionPoco> CompanyJobDescriptions { get; } = new List<CompanyJobDescriptionPoco>();

        public virtual CompanyProfilePoco CompanyProfile { get; set; } = null!;

    }
}
