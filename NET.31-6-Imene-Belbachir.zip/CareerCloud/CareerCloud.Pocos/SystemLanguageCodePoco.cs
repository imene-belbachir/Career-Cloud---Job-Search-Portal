﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareerCloud.Pocos
{
    [Table("System_Language_Codes")]

    public class SystemLanguageCodePoco : IPoco
    {
        
     //   public Guid Id { get; set; }

        // Autres propriétés de la classe
        [Key]
        public string LanguageID { get; set; } = null!;
        [Column("Name")]
        public string Name { get; set; } = null!;
        [Column("Native_Name")]
        public string NativeName { get; set; } = null!;

        public virtual ICollection<CompanyDescriptionPoco> CompanyDescriptions { get; } = new List<CompanyDescriptionPoco>();
        public Guid Id { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
