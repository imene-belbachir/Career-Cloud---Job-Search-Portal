﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;


namespace CareerCloud.Pocos
{
    [Table("Company_Descriptions")]
    public class CompanyDescriptionPoco: IPoco
    {
        [Key]
        public Guid Id { get; set; }
        [Column("Company")]
        public Guid Company { get; set; }
        [Column("LanguageID")]
        public string LanguageId { get; set; } = null!;
        [Column("Company_Name")]
        public string CompanyName { get; set; } = null!;
        [Column("Company_Description")]
        public string CompanyDescription { get; set; } = null!;
        [Column("Time_Stamp")]
        public byte[] TimeStamp { get; set; } = null!;

        public virtual CompanyProfilePoco  CompanyProfile { get; set; } = null!;

        public virtual SystemLanguageCodePoco SystemLanguageCode { get; set; } = null!;

    }
}
