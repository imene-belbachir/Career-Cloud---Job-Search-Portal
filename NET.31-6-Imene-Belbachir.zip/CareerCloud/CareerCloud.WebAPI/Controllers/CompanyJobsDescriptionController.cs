﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/company/v1")]
    [ApiController]
    public class CompanyJobsDescriptionController : ControllerBase
    {
        private readonly CompanyJobDescriptionLogic _logic;

        public CompanyJobsDescriptionController()
        {
            _logic = new CompanyJobDescriptionLogic(new EFGenericRepository<CompanyJobDescriptionPoco>());
        }

        [HttpGet]
        [Route("job/description/{companyJobDescriptionId}")]
        [ProducesResponseType(typeof(CompanyJobDescriptionPoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetCompanyJobsDescription(Guid companyJobDescriptionId)
        {
            var poco = _logic.Get(companyJobDescriptionId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<CompanyJobDescriptionPoco>), 200)]
        public ActionResult GetAllCompanyJobsDescription()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateCompanyJobsDescription(CompanyJobDescriptionPoco poco)
        {
            _logic.Add(new CompanyJobDescriptionPoco[] { poco });
            return CreatedAtAction(nameof(GetCompanyJobsDescription), new { companyJobDescriptionId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateCompanyJobsDescription(CompanyJobDescriptionPoco poco)
        {
            _logic.Update(new CompanyJobDescriptionPoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("DeleteCompanyJobsDescription")]
        public ActionResult DeleteCompanyJobsDescription([FromBody] CompanyJobDescriptionPoco[] pocos)
        {
            try
            {
                // Assuming you have a method to delete company job description records
                _logic.Delete(pocos);
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPost]
        [Route("PostCompanyJobsDescription")]
        public ActionResult PostCompanyJobsDescription([FromBody] CompanyJobDescriptionPoco[] companyJobDescriptions)
        {
            try
            {
                // Votre logique d'implémentation ici...

                // Supposons une création réussie, vous pouvez renvoyer un OkResult.
                return (ActionResult)Ok();
            }
            catch (Exception ex)
            {
                // Journalisez l'exception ou gérez-la comme approprié pour votre application
                return StatusCode(500, "Internal server error");
            }
        }


        [HttpPut]
        [Route("jobsdescription")]
        [ProducesResponseType(204)]
        public ActionResult PutCompanyJobsDescription([FromBody] CompanyJobDescriptionPoco[] pocos)
        {
            try
            {
                _logic.Update(pocos); // Supposons que vous ayez une méthode pour mettre à jour les descriptions de poste de l'entreprise
                return NoContent();
            }
            catch (Exception ex)
            {
                // Journalisez l'exception ou gérez-la comme approprié pour votre application
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
