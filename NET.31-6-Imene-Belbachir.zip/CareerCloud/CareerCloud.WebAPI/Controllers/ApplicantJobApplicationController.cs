﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/applicant/v1")]
    [ApiController]
    public class ApplicantJobApplicationController : ControllerBase
    {
        private readonly ApplicantJobApplicationLogic _logic;

        public ApplicantJobApplicationController()
        {
            _logic = new ApplicantJobApplicationLogic(new EFGenericRepository<ApplicantJobApplicationPoco>());
        }

        [HttpGet]
        [Route("jobapplication/{applicantJobApplicationId}")]
        [ProducesResponseType(typeof(ApplicantJobApplicationPoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetApplicantJobApplication(Guid applicantJobApplicationId)
        {
            var poco = _logic.Get(applicantJobApplicationId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<ApplicantJobApplicationPoco>), 200)]
        public ActionResult GetAllApplicantJobApplication()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateApplicantJobApplication(ApplicantJobApplicationPoco poco)
        {
            _logic.Add(new ApplicantJobApplicationPoco[] { poco });
            return CreatedAtAction(nameof(GetApplicantJobApplication), new { applicantJobApplicationId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateApplicantJobApplication(ApplicantJobApplicationPoco poco)
        {
            _logic.Update(new ApplicantJobApplicationPoco[] { poco });
            return NoContent();
        }
        [HttpDelete]
        [Route("jobapplication")]
        [ProducesResponseType(204)]
        public ActionResult DeleteApplicantJobApplication([FromBody] ApplicantJobApplicationPoco[] pocos)
        {
            try
            {
                // Assuming you have a method to delete multiple applicant job application records
                _logic.Delete(pocos);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }


        [HttpPost]
        [Route("jobapplication")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostApplicantJobApplication([FromBody] ApplicantJobApplicationPoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }
        [HttpPut]
        [Route("PutApplicantJobApplication")]
        public ActionResult PutApplicantJobApplication([FromBody] ApplicantJobApplicationPoco[] pocos)
        {
            try
            {
                _logic.Update(pocos); // Assuming you have a method to update applicant job application records
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
