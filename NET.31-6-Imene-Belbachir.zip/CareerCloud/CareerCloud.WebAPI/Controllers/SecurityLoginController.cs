﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/security/v1")]
    [ApiController]
    public class SecurityLoginController : ControllerBase
    {
        private readonly SecurityLoginLogic _logic;

        public SecurityLoginController()
        {
            _logic = new SecurityLoginLogic(new EFGenericRepository<SecurityLoginPoco>());
        }

        [HttpGet]
        [Route("login/{securityLoginId}")]
        [ProducesResponseType(typeof(SecurityLoginPoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetSecurityLogin(Guid securityLoginId)
        {
            var poco = _logic.Get(securityLoginId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<SecurityLoginPoco>), 200)]
        public ActionResult GetAllSecurityLogin()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateSecurityLogin(SecurityLoginPoco poco)
        {
            _logic.Add(new SecurityLoginPoco[] { poco });
            return CreatedAtAction(nameof(GetSecurityLogin), new { securityLoginId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateSecurityLogin(SecurityLoginPoco poco)
        {
            _logic.Update(new SecurityLoginPoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("logins")]
        [ProducesResponseType(204)]
        public ActionResult DeleteSecurityLogin([FromBody] SecurityLoginPoco[] pocos)
        {
            try
            {
                _logic.Delete(pocos);
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        [Route("securitylogin")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostSecurityLogin([FromBody] SecurityLoginPoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }
        [HttpPut]
        [Route("securitylogin")]
        [ProducesResponseType(204)]
        public ActionResult PutSecurityLogin([FromBody] SecurityLoginPoco[] pocos)
        {
            try
            {
                _logic.Update(pocos); // Mettez à jour les enregistrements de SecurityLogin en fonction des POCOs fournis.
                return NoContent();
            }
            catch (Exception ex)
            {
                // Connectez-vous ou traitez l'exception de manière appropriée pour votre application
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
