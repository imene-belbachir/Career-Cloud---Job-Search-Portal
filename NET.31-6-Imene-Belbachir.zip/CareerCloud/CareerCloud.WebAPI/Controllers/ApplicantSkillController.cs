﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/applicant/v1")]
    [ApiController]
    public class ApplicantSkillController : ControllerBase
    {
        private readonly ApplicantSkillLogic _logic;

        public ApplicantSkillController()
        {
            _logic = new ApplicantSkillLogic(new EFGenericRepository<ApplicantSkillPoco>());
        }

        [HttpGet]
        [Route("skill/{applicantSkillId}")]
        [ProducesResponseType(typeof(ApplicantSkillPoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetApplicantSkill(Guid applicantSkillId)
        {
            var poco = _logic.Get(applicantSkillId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<ApplicantSkillPoco>), 200)]
        public ActionResult GetAllApplicantSkill()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateApplicantSkill(ApplicantSkillPoco poco)
        {
            _logic.Add(new ApplicantSkillPoco[] { poco });
            return CreatedAtAction(nameof(GetApplicantSkill), new { applicantSkillId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateApplicantSkill(ApplicantSkillPoco poco)
        {
            _logic.Update(new ApplicantSkillPoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("skills")]
        [ProducesResponseType(204)]
        public ActionResult DeleteApplicantSkill([FromBody] ApplicantSkillPoco[] pocos)
        {
            try
            {
                _logic.Delete(pocos);
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        [Route("skill")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostApplicantSkill([FromBody] ApplicantSkillPoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }
[HttpPut]
[Route("skill")]
[ProducesResponseType(204)]
public ActionResult PutApplicantSkill([FromBody] ApplicantSkillPoco[] pocos)
{
    try
    {
        _logic.Update(pocos); // Mettez à jour les enregistrements d'ApplicantSkill en fonction des POCOs fournis.
        return NoContent();
    }
    catch (Exception ex)
    {
        // Connectez-vous ou traitez l'exception de manière appropriée pour votre application
        return StatusCode(500, "Internal server error");
    }
}

    }
}
