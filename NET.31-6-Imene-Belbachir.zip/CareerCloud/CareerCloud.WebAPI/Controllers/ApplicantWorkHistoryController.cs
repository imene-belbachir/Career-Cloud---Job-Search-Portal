﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/applicant/v1")]
    [ApiController]
    public class ApplicantWorkHistoryController : ControllerBase
    {
        private readonly ApplicantWorkHistoryLogic _logic;

        public ApplicantWorkHistoryController()
        {
            _logic = new ApplicantWorkHistoryLogic(new EFGenericRepository<ApplicantWorkHistoryPoco>());
        }

        [HttpGet]
        [Route("workhistory/{applicantWorkHistoryId}")]
        [ProducesResponseType(typeof(ApplicantWorkHistoryPoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetApplicantWorkHistory(Guid applicantWorkHistoryId)
        {
            var poco = _logic.Get(applicantWorkHistoryId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<ApplicantWorkHistoryPoco>), 200)]
        public ActionResult GetAllApplicantWorkHistory()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateApplicantWorkHistory(ApplicantWorkHistoryPoco poco)
        {
            _logic.Add(new ApplicantWorkHistoryPoco[] { poco });
            return CreatedAtAction(nameof(GetApplicantWorkHistory), new { applicantWorkHistoryId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateApplicantWorkHistory(ApplicantWorkHistoryPoco poco)
        {
            _logic.Update(new ApplicantWorkHistoryPoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("workhistory")]
        [ProducesResponseType(204)]
        public ActionResult DeleteApplicantWorkHistory([FromBody] ApplicantWorkHistoryPoco[] pocos)
        {
            try
            {
                _logic.Delete(pocos);
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        [Route("workhistory")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostApplicantWorkHistory([FromBody] ApplicantWorkHistoryPoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }
        [HttpPut]
        [Route("workhistory")]
        [ProducesResponseType(204)]
        public ActionResult PutApplicantWorkHistory([FromBody] ApplicantWorkHistoryPoco[] pocos)
        {
            try
            {
                _logic.Update(pocos); // Mettez à jour les enregistrements d'ApplicantWorkHistory en fonction des POCOs fournis.
                return NoContent();
            }
            catch (Exception ex)
            {
                // Connectez-vous ou traitez l'exception de manière appropriée pour votre application
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
