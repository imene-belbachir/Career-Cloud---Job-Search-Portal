﻿
using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/system/v1")]
    [ApiController]
    public class SystemLanguageCodeController : ControllerBase
    {
        private readonly SystemLanguageCodeLogic _logic;

        public SystemLanguageCodeController()
        {
            _logic = new SystemLanguageCodeLogic(new EFGenericRepository<SystemLanguageCodePoco>());
        }

        [HttpGet]
        [Route("languagecode/{systemLanguageCodeId}")]
        [ProducesResponseType(typeof(SystemLanguageCodePoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetSystemLanguageCode(string systemLanguageCodeId)
        {
            // Convert the string to Guid for processing
            if (!Guid.TryParse(systemLanguageCodeId, out Guid languageIdGuid))
            {
                // Handle the case where the string is not a valid Guid
                return BadRequest("Invalid LanguageID format");
            }

            var poco = _logic.Get(languageIdGuid);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<SystemLanguageCodePoco>), 200)]
        public ActionResult GetAllSystemLanguageCode()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateSystemLanguageCode(SystemLanguageCodePoco poco)
        {
            _logic.Add(new SystemLanguageCodePoco[] { poco });
            return CreatedAtAction(nameof(GetSystemLanguageCode), new { systemLanguageCodeId = poco.LanguageID }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateSystemLanguageCode(SystemLanguageCodePoco poco)
        {
            _logic.Update(new SystemLanguageCodePoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("languagecode")]
        [ProducesResponseType(204)]
        public ActionResult DeleteSystemLanguageCode([FromBody] SystemLanguageCodePoco[] pocos)
        {
            try
            {
                _logic.Delete(pocos);
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        [Route("systemlanguagecode")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostSystemLanguageCode([FromBody] SystemLanguageCodePoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }
        [HttpPut]
        [Route("systemlanguagecode")]
        [ProducesResponseType(204)]
        public ActionResult PutSystemLanguageCode([FromBody] SystemLanguageCodePoco[] pocos)
        {
            try
            {
                _logic.Update(pocos);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
