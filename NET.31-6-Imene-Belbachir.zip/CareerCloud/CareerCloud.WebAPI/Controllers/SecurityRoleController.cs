﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/security/v1")]
    [ApiController]
    public class SecurityRoleController : ControllerBase
    {
        private readonly SecurityRoleLogic _logic;

        public SecurityRoleController()
        {
            _logic = new SecurityRoleLogic(new EFGenericRepository<SecurityRolePoco>());
        }

        [HttpGet]
        [Route("role/{securityRoleId}")]
        [ProducesResponseType(typeof(SecurityRolePoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetSecurityRole(Guid securityRoleId)
        {
            var poco = _logic.Get(securityRoleId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<SecurityRolePoco>), 200)]
        public ActionResult GetAllSecurityRole()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateSecurityRole(SecurityRolePoco poco)
        {
            _logic.Add(new SecurityRolePoco[] { poco });
            return CreatedAtAction(nameof(GetSecurityRole), new { securityRoleId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateSecurityRole(SecurityRolePoco poco)
        {
            _logic.Update(new SecurityRolePoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("securityrole")]
        [ProducesResponseType(204)]
        public ActionResult DeleteSecurityRole(SecurityRolePoco[] securityRoles)
        {
            if (securityRoles == null || securityRoles.Length == 0)
            {
                return BadRequest();
            }

            foreach (var securityRole in securityRoles)
            {
                if (securityRole != null)
                {
                    // Assume _logic.Delete method accepts an array of SecurityRolePoco
                    _logic.Delete(new SecurityRolePoco[] { securityRole });
                }
            }

            return NoContent();
        }

        [HttpPost]
        [Route("securityrole")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostSecurityRole([FromBody] SecurityRolePoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }
        [HttpPut]
        [Route("securityrole")]
        [ProducesResponseType(204)]
        public ActionResult PutSecurityRole(SecurityRolePoco[] securityRoles)
        {
            if (securityRoles == null || securityRoles.Length == 0)
            {
                return BadRequest();
            }

            foreach (var securityRole in securityRoles)
            {
                if (securityRole != null)
                {
                    // Assume _logic.Update method accepts an array of SecurityRolePoco
                    _logic.Update(new SecurityRolePoco[] { securityRole });
                }
            }

            return NoContent();
        }

    }
}
