﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/company/v1")]
    [ApiController]
    public class CompanyLocationController : ControllerBase
    {
        private readonly CompanyLocationLogic _logic;

        public CompanyLocationController()
        {
            _logic = new CompanyLocationLogic(new EFGenericRepository<CompanyLocationPoco>());
        }

        [HttpGet]
        [Route("location/{companyLocationId}")]
        [ProducesResponseType(typeof(CompanyLocationPoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetCompanyLocation(Guid companyLocationId)
        {
            var poco = _logic.Get(companyLocationId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<CompanyLocationPoco>), 200)]
        public ActionResult GetAllCompanyLocation()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateCompanyLocation(CompanyLocationPoco poco)
        {
            _logic.Add(new CompanyLocationPoco[] { poco });
            return CreatedAtAction(nameof(GetCompanyLocation), new { companyLocationId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateCompanyLocation(CompanyLocationPoco poco)
        {
            _logic.Update(new CompanyLocationPoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("locations")]
        [ProducesResponseType(204)]
        public ActionResult DeleteCompanyLocation([FromBody] CompanyLocationPoco[] pocos)
        {
            try
            {
                _logic.Delete(pocos);
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        [Route("companylocation")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostCompanyLocation([FromBody] CompanyLocationPoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }
        [HttpPut]
        [Route("location")]
        [ProducesResponseType(204)]
        public ActionResult PutCompanyLocation([FromBody] CompanyLocationPoco[] pocos)
        {
            try
            {
                _logic.Update(pocos); // Mettez à jour les enregistrements de CompanyLocation en fonction des POCOs fournis.
                return NoContent();
            }
            catch (Exception ex)
            {
                // Connectez-vous ou traitez l'exception de manière appropriée pour votre application
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
