﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/company/v1")]
    [ApiController]
    public class CompanyJobController : ControllerBase
    {
        private readonly CompanyJobLogic _logic;

        public CompanyJobController()
        {
            _logic = new CompanyJobLogic(new EFGenericRepository<CompanyJobPoco>());
        }

        [HttpGet]
        [Route("job/{companyJobId}")]
        [ProducesResponseType(typeof(CompanyJobPoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetCompanyJob(Guid companyJobId)
        {
            var poco = _logic.Get(companyJobId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<CompanyJobPoco>), 200)]
        public ActionResult GetAllCompanyJob()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateCompanyJob(CompanyJobPoco poco)
        {
            _logic.Add(new CompanyJobPoco[] { poco });
            return CreatedAtAction(nameof(GetCompanyJob), new { companyJobId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateCompanyJob(CompanyJobPoco poco)
        {
            _logic.Update(new CompanyJobPoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("companyjob")]
        [ProducesResponseType(204)]
        public ActionResult DeleteCompanyJob(CompanyJobPoco[] companyJobs)
        {
            if (companyJobs == null || companyJobs.Length == 0)
            {
                return BadRequest("Company jobs cannot be null or empty.");
            }

            foreach (var companyJob in companyJobs)
            {
                var poco = _logic.Get(companyJob.Id);
                if (poco != null)
                {
                    _logic.Delete(new CompanyJobPoco[] { poco });
                }
            }

            return NoContent();
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult PostCompanyJob(IEnumerable<CompanyJobPoco> pocos)
        {
            _logic.Add(pocos.ToArray());
            return Ok();
        }
        [HttpPut]
        [Route("companyjob")]
        [ProducesResponseType(204)]
        public ActionResult PutCompanyJob(CompanyJobPoco[] companyJobs)
        {
            if (companyJobs == null || companyJobs.Length == 0)
            {
                return BadRequest();
            }

            foreach (var companyJob in companyJobs)
            {
                if (companyJob != null)
                {
                    // Assume _logic.Update method accepts an array of CompanyJobPoco
                    _logic.Update(new CompanyJobPoco[] { companyJob });
                }
            }

            return NoContent();
        }

    }
}
