﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/company/v1")]
    [ApiController]
    public class CompanyJobSkillController : ControllerBase
    {
        private readonly CompanyJobSkillLogic _logic;

        public CompanyJobSkillController()
        {
            _logic = new CompanyJobSkillLogic(new EFGenericRepository<CompanyJobSkillPoco>());
        }

        [HttpGet]
        [Route("job/skill/{companyJobSkillId}")]
        [ProducesResponseType(typeof(CompanyJobSkillPoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetCompanyJobSkill(Guid companyJobSkillId)
        {
            var poco = _logic.Get(companyJobSkillId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<CompanyJobSkillPoco>), 200)]
        public ActionResult GetAllCompanyJobSkill()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateCompanyJobSkill(CompanyJobSkillPoco poco)
        {
            _logic.Add(new CompanyJobSkillPoco[] { poco });
            return CreatedAtAction(nameof(GetCompanyJobSkill), new { companyJobSkillId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateCompanyJobSkill(CompanyJobSkillPoco poco)
        {
            _logic.Update(new CompanyJobSkillPoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("DeleteCompanyJobSkill")]
        public ActionResult DeleteCompanyJobSkill([FromBody] CompanyJobSkillPoco[] pocos)
        {
            try
            {
                _logic.Delete(pocos); // Assuming you have a method to delete company job skill records
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPost]
        [Route("companyjobskill")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostCompanyJobSkill([FromBody] CompanyJobSkillPoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }
        [HttpPut]
        [Route("PutCompanyJobSkill")]
        public ActionResult PutCompanyJobSkill([FromBody] CompanyJobSkillPoco[] pocos)
        {
            try
            {
                _logic.Update(pocos); // Assuming you have a method to update company job skill records
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
