﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/applicant/v1")]
    [ApiController]
    public class ApplicantResumeController : ControllerBase
    {
        private readonly ApplicantResumeLogic _logic;

        public ApplicantResumeController()
        {
            _logic = new ApplicantResumeLogic(new EFGenericRepository<ApplicantResumePoco>());
        }

        [HttpGet]
        [Route("resume/{applicantResumeId}")]
        [ProducesResponseType(typeof(ApplicantResumePoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetApplicantResume(Guid applicantResumeId)
        {
            var poco = _logic.Get(applicantResumeId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<ApplicantResumePoco>), 200)]
        public ActionResult GetAllApplicantResume()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateApplicantResume(ApplicantResumePoco poco)
        {
            _logic.Add(new ApplicantResumePoco[] { poco });
            return CreatedAtAction(nameof(GetApplicantResume), new { applicantResumeId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateApplicantResume(ApplicantResumePoco poco)
        {
            _logic.Update(new ApplicantResumePoco[] { poco });
            return NoContent();
        }

       
        [HttpDelete]
        [Route("resumes")]
        [ProducesResponseType(204)]
      
        public ActionResult DeleteApplicantResume([FromBody] ApplicantResumePoco[] pocos)
        {
            try
            {
                _logic.Delete(pocos); // Assuming you have a method to delete applicant education records
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }


        [HttpPost]
        [Route("resume")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostApplicantResume([FromBody] ApplicantResumePoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }
        [HttpPut]
        [Route("resume")]
        [ProducesResponseType(204)]
        public ActionResult PutApplicantResume([FromBody] ApplicantResumePoco[] pocos)
        {
            try
            {
                _logic.Update(pocos); // Mettez à jour les enregistrements d'ApplicantResume en fonction des POCOs fournis.
                return NoContent();
            }
            catch (Exception ex)
            {
                // Connectez-vous ou traitez l'exception de manière appropriée pour votre application
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
