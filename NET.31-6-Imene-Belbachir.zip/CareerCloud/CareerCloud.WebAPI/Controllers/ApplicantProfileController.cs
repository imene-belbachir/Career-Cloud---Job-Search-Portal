﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/applicant/v1")]
    [ApiController]
    public class ApplicantProfileController : ControllerBase
    {
        private readonly ApplicantProfileLogic _logic;

        public ApplicantProfileController()
        {
            _logic = new ApplicantProfileLogic(new EFGenericRepository<ApplicantProfilePoco>());
        }

        [HttpGet]
        [Route("profile/{applicantProfileId}")]
        [ProducesResponseType(typeof(ApplicantProfilePoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetApplicantProfile(Guid applicantProfileId)
        {
            var poco = _logic.Get(applicantProfileId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<ApplicantProfilePoco>), 200)]
        public ActionResult GetAllApplicantProfile()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateApplicantProfile(ApplicantProfilePoco poco)
        {
            _logic.Add(new ApplicantProfilePoco[] { poco });
            return CreatedAtAction(nameof(GetApplicantProfile), new { applicantProfileId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateApplicantProfile(ApplicantProfilePoco poco)
        {
            _logic.Update(new ApplicantProfilePoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("profiles")]
        [ProducesResponseType(204)]
        public ActionResult DeleteApplicantProfile([FromBody] ApplicantProfilePoco[] pocos)
        {
            try
            {
                _logic.Delete(pocos);
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        [Route("profile")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostApplicantProfile([FromBody] ApplicantProfilePoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }
        [HttpPut]
        [Route("PutApplicantProfile")]
        [ProducesResponseType(204)]
        public ActionResult PutApplicantProfile([FromBody] ApplicantProfilePoco[] pocos)
        {
            try
            {
                // Assuming you have a method to update applicant profile records
                _logic.Update(pocos);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
