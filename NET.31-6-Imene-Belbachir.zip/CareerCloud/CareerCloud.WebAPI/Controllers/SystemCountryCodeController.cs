﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/system/v1")]
    [ApiController]
    public class SystemCountryCodeController : ControllerBase
    {
        private readonly SystemCountryCodeLogic _logic;

        public SystemCountryCodeController()
        {
            _logic = new SystemCountryCodeLogic(new EFGenericRepository<SystemCountryCodePoco>());
        }

        [HttpGet]
        [Route("countrycode/{systemCountryCodeId}")]
        [ProducesResponseType(typeof(SystemCountryCodePoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetSystemCountryCode(string systemCountryCodeId)
        {
            // Convert the string to Guid
            if (!Guid.TryParse(systemCountryCodeId, out Guid countryCodeGuid))
            {
                // Handle the case where the string is not a valid Guid
                return NotFound();
            }

            var poco = _logic.Get(countryCodeGuid);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }


        [HttpGet]
        [ProducesResponseType(typeof(List<SystemCountryCodePoco>), 200)]
        public ActionResult GetAllSystemCountryCode()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateSystemCountryCode(SystemCountryCodePoco poco)
        {
            _logic.Add(new SystemCountryCodePoco[] { poco });
            return CreatedAtAction(nameof(GetSystemCountryCode), new { systemCountryCodeId = poco.Code }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateSystemCountryCode(SystemCountryCodePoco poco)
        {
            _logic.Update(new SystemCountryCodePoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("countrycode")]
        [ProducesResponseType(204)]
        public ActionResult DeleteSystemCountryCode([FromBody] SystemCountryCodePoco[] pocos)
        {
            try
            {
                _logic.Delete(pocos);
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        [Route("systemcountrycode")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostSystemCountryCode([FromBody] SystemCountryCodePoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }
        [HttpPut]
        [Route("systemcountrycode")]
        [ProducesResponseType(204)]
        public ActionResult PutSystemCountryCode([FromBody] SystemCountryCodePoco[] pocos)
        {
            try
            {
                _logic.Update(pocos);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }

    }
}




