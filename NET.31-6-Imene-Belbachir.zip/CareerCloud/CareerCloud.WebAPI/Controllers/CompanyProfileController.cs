﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/company/v1")]
    [ApiController]
    public class CompanyProfileController : ControllerBase
    {
        private readonly CompanyProfileLogic _logic;

        public CompanyProfileController()
        {
            _logic = new CompanyProfileLogic(new EFGenericRepository<CompanyProfilePoco>());
        }

        [HttpGet]
        [Route("profile/{companyProfileId}")]
        [ProducesResponseType(typeof(CompanyProfilePoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetCompanyProfile(Guid companyProfileId)
        {
            var poco = _logic.Get(companyProfileId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<CompanyProfilePoco>), 200)]
        public ActionResult GetAllCompanyProfile()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateCompanyProfile(CompanyProfilePoco poco)
        {
            _logic.Add(new CompanyProfilePoco[] { poco });
            return CreatedAtAction(nameof(GetCompanyProfile), new { companyProfileId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateCompanyProfile(CompanyProfilePoco poco)
        {
            _logic.Update(new CompanyProfilePoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("companyprofile")]
        [ProducesResponseType(204)]
        public ActionResult DeleteCompanyProfile(CompanyProfilePoco[] companyProfiles)
        {
            if (companyProfiles == null || companyProfiles.Length == 0)
            {
                return BadRequest();
            }

            foreach (var companyProfile in companyProfiles)
            {
                if (companyProfile != null)
                {
                    _logic.Delete(new CompanyProfilePoco[] { companyProfile });
                }
            }

            return NoContent();
        }


        [HttpPost]
        [Route("companyprofile")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostCompanyProfile([FromBody] CompanyProfilePoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }


        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult PutCompanyProfile(IEnumerable<CompanyProfilePoco> pocos)
        {
            _logic.Update(pocos.ToArray());
            return NoContent();
        }
        

    }
}
