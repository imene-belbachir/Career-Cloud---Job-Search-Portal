﻿//using Microsoft.AspNetCore.Http;
/*using Microsoft.AspNetCore.Mvc;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicantEducationController : ControllerBase
    {
    }
}
*/
using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/applicant/v1")]
    [ApiController]
    public class ApplicantEducationController : ControllerBase
    {
        private readonly ApplicantEducationLogic _logic;

        public ApplicantEducationController()
        {
            
            _logic = new ApplicantEducationLogic(new EFGenericRepository<ApplicantEducationPoco>());
          
        }

        [HttpGet]
        [Route("education/{applicantEducationId}")]
        [ProducesResponseType(typeof(ApplicantEducationPoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetApplicantEducation(Guid applicantEducationId)
        {
            var poco = _logic.Get(applicantEducationId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<ApplicantEducationPoco>), 200)]
        public ActionResult GetAllApplicantEducation()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateApplicantEducation(ApplicantEducationPoco poco)
        {
            _logic.Add(new ApplicantEducationPoco[] { poco });
            return CreatedAtAction(nameof(GetApplicantEducation), new { applicantEducationId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateApplicantEducation(ApplicantEducationPoco poco)
        {
            _logic.Update(new ApplicantEducationPoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("DeleteApplicantEducation")]
        public ActionResult DeleteApplicantEducation([FromBody] ApplicantEducationPoco[] pocos)
        {
            try
            {
                _logic.Delete(pocos); // Assuming you have a method to delete applicant education records
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPost]
        [Route("education")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostApplicantEducation([FromBody] ApplicantEducationPoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }
        [HttpPut]
        [Route("PutApplicantEducation")]
        public ActionResult PutApplicantEducation([FromBody] ApplicantEducationPoco[] pocos)
        {
            try
            {
                _logic.Update(pocos); // Assuming you have a method to update applicant education records
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
