﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/company/v1")]
    [ApiController]
    public class CompanyDescriptionController : ControllerBase
    {
        private readonly CompanyDescriptionLogic _logic;

        public CompanyDescriptionController()
        {
            _logic = new CompanyDescriptionLogic(new EFGenericRepository<CompanyDescriptionPoco>());
        }

        [HttpGet]
        [Route("description/{companyDescriptionId}")]
        [ProducesResponseType(typeof(CompanyDescriptionPoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetCompanyDescription(Guid companyDescriptionId)
        {
            var poco = _logic.Get(companyDescriptionId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<CompanyDescriptionPoco>), 200)]
        public ActionResult GetAllCompanyDescription()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateCompanyDescription(CompanyDescriptionPoco poco)
        {
            _logic.Add(new CompanyDescriptionPoco[] { poco });
            return CreatedAtAction(nameof(GetCompanyDescription), new { companyDescriptionId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateCompanyDescription(CompanyDescriptionPoco poco)
        {
            _logic.Update(new CompanyDescriptionPoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("companydescription")]
        [ProducesResponseType(204)]
        public ActionResult DeleteCompanyDescription(CompanyDescriptionPoco[] companyDescriptions)
        {
            if (companyDescriptions == null || companyDescriptions.Length == 0)
            {
                return BadRequest();
            }

            foreach (var companyDescription in companyDescriptions)
            {
                if (companyDescription != null)
                {
                    // Assume _logic.Delete method accepts an array of CompanyDescriptionPoco
                    _logic.Delete(new CompanyDescriptionPoco[] { companyDescription });
                }
            }

            return NoContent();
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult PostCompanyDescription(IEnumerable<CompanyDescriptionPoco> pocos)
        {
            _logic.Add(pocos.ToArray());
            return Ok();
        }

        [HttpPut]
        [Route("companydescription")]
        [ProducesResponseType(204)]
        public ActionResult PutCompanyDescription(CompanyDescriptionPoco[] companyDescriptions)
        {
            if (companyDescriptions == null || companyDescriptions.Length == 0)
            {
                return BadRequest();
            }

            foreach (var companyDescription in companyDescriptions)
            {
                if (companyDescription != null)
                {
                    _logic.Update(new CompanyDescriptionPoco[] { companyDescription });
                }
            }

            return NoContent();
        }

    }
}
