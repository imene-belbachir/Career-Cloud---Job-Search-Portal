﻿using Microsoft.AspNetCore.Mvc;
using CareerCloud.Pocos;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;

namespace CareerCloud.WebAPI.Controllers
{
    [Route("api/careercloud/security/v1")]
    [ApiController]
    public class SecurityLoginsRoleController : ControllerBase
    {
        private readonly SecurityLoginsRoleLogic _logic;

        public SecurityLoginsRoleController()
        {
            _logic = new SecurityLoginsRoleLogic(new EFGenericRepository<SecurityLoginsRolePoco>());
        }

        [HttpGet]
        [Route("loginsrole/{securityLoginsRoleId}")]
        [ProducesResponseType(typeof(SecurityLoginsRolePoco), 200)]
        [ProducesResponseType(404)]
        public ActionResult GetSecurityLoginsRole(Guid securityLoginsRoleId)
        {
            var poco = _logic.Get(securityLoginsRoleId);
            if (poco == null)
            {
                return NotFound();
            }
            return Ok(poco);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<SecurityLoginsRolePoco>), 200)]
        public ActionResult GetAllSecurityLoginsRole()
        {
            var pocos = _logic.GetAll();
            return Ok(pocos);
        }

        [HttpPost]
        [ProducesResponseType(201)]
        public ActionResult CreateSecurityLoginsRole(SecurityLoginsRolePoco poco)
        {
            _logic.Add(new SecurityLoginsRolePoco[] { poco });
            return CreatedAtAction(nameof(GetSecurityLoginsRole), new { securityLoginsRoleId = poco.Id }, poco);
        }

        [HttpPut]
        [ProducesResponseType(204)]
        public ActionResult UpdateSecurityLoginsRole(SecurityLoginsRolePoco poco)
        {
            _logic.Update(new SecurityLoginsRolePoco[] { poco });
            return NoContent();
        }

        [HttpDelete]
        [Route("loginsrole")]
        [ProducesResponseType(204)]
        public ActionResult DeleteSecurityLoginRole([FromBody] SecurityLoginsRolePoco[] pocos)
        {
            try
            {
                _logic.Delete(pocos);
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        [Route("loginrole")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult PostSecurityLoginRole([FromBody] SecurityLoginsRolePoco[] pocos)
        {
            _logic.Add(pocos);
            return Ok();
        }

    }
}
