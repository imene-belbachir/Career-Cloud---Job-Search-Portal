﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CareerCloud.Pocos;
using Microsoft.EntityFrameworkCore;

namespace CareerCloud.EntityFrameworkDataAccess
{
    public partial class CareerCloudContext : DbContext
    {
        public CareerCloudContext()
        {
        }

        public CareerCloudContext(DbContextOptions<CareerCloudContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ApplicantEducationPoco> ApplicantEducations { get; set; }

        public virtual DbSet<ApplicantJobApplicationPoco> ApplicantJobApplications { get; set; }

        public virtual DbSet<ApplicantProfilePoco> ApplicantProfiles { get; set; }

        public virtual DbSet<ApplicantResumePoco> ApplicantResumes { get; set; }

        public virtual DbSet<ApplicantSkillPoco> ApplicantSkills { get; set; }

        public virtual DbSet<ApplicantWorkHistoryPoco> ApplicantWorkHistories { get; set; }

        public virtual DbSet<CompanyDescriptionPoco> CompanyDescriptions { get; set; }

        public virtual DbSet<CompanyJobPoco> CompanyJobs { get; set; }

        public virtual DbSet<CompanyJobEducationPoco> CompanyJobEducations { get; set; }

        public virtual DbSet<CompanyJobSkillPoco> CompanyJobSkills { get; set; }

        public virtual DbSet<CompanyJobDescriptionPoco> CompanyJobsDescriptions { get; set; }

        public virtual DbSet<CompanyLocationPoco> CompanyLocations { get; set; }

        public virtual DbSet<CompanyProfilePoco> CompanyProfiles { get; set; }

        public virtual DbSet<SecurityLoginPoco> SecurityLogins { get; set; }

        public virtual DbSet<SecurityLoginsLogPoco> SecurityLoginsLogs { get; set; }

        public virtual DbSet<SecurityLoginsRolePoco> SecurityLoginsRoles { get; set; }

        public virtual DbSet<SecurityRolePoco> SecurityRoles { get; set; }

        public virtual DbSet<SystemCountryCodePoco> SystemCountryCodes { get; set; }

        public virtual DbSet<SystemLanguageCodePoco> SystemLanguageCodes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)

            => optionsBuilder.UseSqlServer("Server=IMENE;Database=JOB_PORTAL_DB;Integrated Security=True;Encrypt=False");

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ApplicantEducationPoco>(entity =>
            {
               
               entity.Property(e => e.TimeStamp)
                   .IsRowVersion()
                   .IsConcurrencyToken()
                   .HasColumnName("Time_Stamp");

                entity.HasOne(d => d.ApplicantProfile).WithMany(p => p.ApplicantEducations)
                    .HasForeignKey(d => d.Applicant)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Applicant_Educations_Applicant_Profiles");
            });

            modelBuilder.Entity<ApplicantJobApplicationPoco>(entity =>
            {
               
                entity.Property(e => e.TimeStamp)
                       .IsRowVersion()
                       .IsConcurrencyToken()
                       .HasColumnName("Time_Stamp");
                entity.HasOne(d => d.ApplicantProfile).WithMany(p => p.ApplicantJobApplications)
                    .HasForeignKey(d => d.Applicant)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Applicant_Job_Applications_Applicant_Profiles");

                entity.HasOne(d => d.CompanyJob).WithMany(p => p.ApplicantJobApplications)
                    .HasForeignKey(d => d.Job)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Applicant_Job_Applications_Company_Jobs");
            });

            modelBuilder.Entity<ApplicantProfilePoco>(entity =>
            {
                
                entity.Property(e => e.TimeStamp)
                      .IsRowVersion()
                      .IsConcurrencyToken()
                      .HasColumnName("Time_Stamp");
                entity.HasOne(d => d.SystemCountryCode).WithMany(p => p.ApplicantProfiles)
                    .HasForeignKey(d => d.Country)
                    .HasPrincipalKey(sc => sc.Code) 
                    .HasConstraintName("FK_Applicant_Profiles_System_Country_Codes");


                entity.HasOne(d => d.LoginNavigation).WithMany(p => p.ApplicantProfiles)
                    .HasForeignKey(d => d.Login)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Applicant_Profiles_Security_Logins");
                
            });

            modelBuilder.Entity<ApplicantResumePoco>(entity =>
            {
             
                entity.HasOne(d => d.ApplicantProfile).WithMany(p => p.ApplicantResumes)
                    .HasForeignKey(d => d.Applicant)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Applicant_Resumes_Applicant_Profiles");
            });

            modelBuilder.Entity<ApplicantSkillPoco>(entity =>
            {
                
                entity.Property(e => e.TimeStamp)
                     .IsRowVersion()
                     .IsConcurrencyToken()
                     .HasColumnName("Time_Stamp");
                entity.HasOne(d => d.ApplicantProfile).WithMany(p => p.ApplicantSkills)
                    .HasForeignKey(d => d.Applicant)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Applicant_Skills_Applicant_Profiles");
            });

            modelBuilder.Entity<ApplicantWorkHistoryPoco>(entity =>
            {
                
                entity.Property(e => e.TimeStamp)
                     .IsRowVersion()
                     .IsConcurrencyToken()
                     .HasColumnName("Time_Stamp");
                entity.HasOne(d => d.ApplicantProfile).WithMany(p => p.ApplicantWorkHistorys)
                    .HasForeignKey(d => d.Applicant)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Applicant_Work_Experiences_Applicant_Profiles");

                entity.HasOne(d => d.SystemCountryCode).WithMany(p => p.ApplicantWorkHistories)
                    .HasForeignKey(d => d.CountryCode)
                     .HasPrincipalKey(sc => sc.Code)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Applicant_Work_History_System_Country_Codes");
            });

            modelBuilder.Entity<CompanyDescriptionPoco>(entity =>
            {
                
                entity.Property(e => e.TimeStamp)
                   .IsRowVersion()
                   .IsConcurrencyToken()
                   .HasColumnName("Time_Stamp");
                entity.HasOne(d => d.CompanyProfile).WithMany(p => p.CompanyDescriptions)
                    .HasForeignKey(d => d.Company)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Company_Descriptions_Company_Profiles");

                entity.HasOne(d => d.SystemLanguageCode).WithMany(p => p.CompanyDescriptions)
                    .HasForeignKey(d => d.LanguageId)
                     .HasPrincipalKey(sc => sc.LanguageID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Company_Descriptions_System_Language_Codes");
            });

            modelBuilder.Entity<CompanyJobPoco>(entity =>
            {
              
                entity.Property(e => e.TimeStamp)
                     .IsRowVersion()
                     .IsConcurrencyToken()
                     .HasColumnName("Time_Stamp");
                entity.HasOne(d => d.CompanyProfile).WithMany(p => p.CompanyJobs)
                    .HasForeignKey(d => d.Company)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Company_Jobs_Company_Profiles");
            });

            modelBuilder.Entity<CompanyJobEducationPoco>(entity =>
            {
               
                entity.Property(e => e.TimeStamp)
                    .IsRowVersion()
                    .IsConcurrencyToken()
                    .HasColumnName("Time_Stamp");
                entity.HasOne(d => d.CompanyJob).WithMany(p => p.CompanyJobEducations)
                    .HasForeignKey(d => d.Job)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Company_Job_Educations_Company_Jobs");
            });

            modelBuilder.Entity<CompanyJobSkillPoco>(entity =>
            {
                
                entity.Property(e => e.TimeStamp)
                        .IsRowVersion()
                        .IsConcurrencyToken()
                        .HasColumnName("Time_Stamp");
                entity.HasOne(d => d.CompanyJob).WithMany(p => p.CompanyJobSkills)
                    .HasForeignKey(d => d.Job)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Company_Job_Skills_Company_Jobs");
            });

            modelBuilder.Entity<CompanyJobDescriptionPoco>(entity =>
            {
                
                entity.Property(e => e.TimeStamp)
                       .IsRowVersion()
                       .IsConcurrencyToken()
                       .HasColumnName("Time_Stamp");
                entity.HasOne(d => d.CompanyJob).WithMany(p => p.CompanyJobDescriptions)
                    .HasForeignKey(d => d.Job)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Company_Jobs_Descriptions_Company_Jobs");
            });

            modelBuilder.Entity<CompanyLocationPoco>(entity =>
            {
                
                entity.Property(e => e.TimeStamp)
                       .IsRowVersion()
                       .IsConcurrencyToken()
                       .HasColumnName("Time_Stamp");
                entity.HasOne(d => d.CompanyProfile).WithMany(p => p.CompanyLocations)
                    .HasForeignKey(d => d.Company)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Company_Locations_Company_Profiles");
                entity.HasOne(cl => cl.SystemCountryCode)
            .WithMany()
            .HasForeignKey(cl => cl.CountryCode)
             .HasPrincipalKey(sc => sc.Code)
            .OnDelete(DeleteBehavior.ClientSetNull)
            .HasConstraintName("FK_Company_Locations_System_Country_Codes");
            });

            modelBuilder.Entity<CompanyProfilePoco>(entity =>
            {
               
                entity.Property(e => e.TimeStamp)
                      .IsRowVersion()
                      .IsConcurrencyToken()
                      .HasColumnName("Time_Stamp");
            });

            modelBuilder.Entity<SecurityLoginPoco>(entity =>
            {
               
                entity.Property(e => e.TimeStamp)
                     .IsRowVersion()
                     .IsConcurrencyToken()
                     .HasColumnName("Time_Stamp");
            });

            modelBuilder.Entity<SecurityLoginsLogPoco>(entity =>
            {
              
                entity.HasOne(d => d.SecurityLogin).WithMany(p => p.SecurityLoginsLogs)
                    .HasForeignKey(d => d.Login)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Security_Logins_Log_Security_Logins");
            });

            modelBuilder.Entity<SecurityLoginsRolePoco>(entity =>
            {
               
                entity.Property(e => e.TimeStamp)
                       .IsRowVersion()
                       .IsConcurrencyToken()
                       .HasColumnName("Time_Stamp");
                entity.HasOne(d => d.SecurityLogin).WithMany(p => p.SecurityLoginsRoles)
                    .HasForeignKey(d => d.Login)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Security_Logins_Roles_Security_Logins");

                entity.HasOne(d => d.SecurityRole).WithMany(p => p.SecurityLoginsRoles)
                    .HasForeignKey(d => d.Role)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Security_Logins_Roles_Security_Roles");
            });

            modelBuilder.Entity<SecurityRolePoco>(entity =>
            {
           
            });

            modelBuilder.Entity<SystemCountryCodePoco>(entity =>
            {
             
            });

            modelBuilder.Entity<SystemLanguageCodePoco>(entity =>
            {
              
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
