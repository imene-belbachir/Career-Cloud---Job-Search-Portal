﻿
using CareerCloud.BusinessLogicLayer;
using CareerCloud.DataAccessLayer;
using CareerCloud.Pocos;
using System.Text.RegularExpressions;

public class CompanyProfileLogic : BaseLogic<CompanyProfilePoco>
{
    public CompanyProfileLogic(IDataRepository<CompanyProfilePoco> repository) : base(repository)
    {
    }

    public override void Add(CompanyProfilePoco[] pocos)
    {
        Verify(pocos);
        base.Add(pocos);
    }

    public override void Update(CompanyProfilePoco[] pocos)
    {
        Verify(pocos);
        base.Update(pocos);
    }

    public override void Verify(CompanyProfilePoco[] pocos)
    {
        List<ValidationException> exceptions = new List<ValidationException>();

        foreach (var poco in pocos)
        {
          
            if (!string.IsNullOrEmpty(poco.CompanyWebsite) && !IsValidWebsite(poco.CompanyWebsite))
            {
                exceptions.Add(new ValidationException(600, $"Invalid website format for CompanyProfile {poco.Id}."));
            }

            if (!IsValidPhoneNumber(poco.ContactPhone))
            {
                exceptions.Add(new ValidationException(601, $"Invalid phone number format for CompanyProfile {poco.Id}."));
            }

            if (!string.IsNullOrEmpty(poco.ContactPhone) && poco.ContactPhone.StartsWith("416-"))
            {
                exceptions.Add(new ValidationException(602, $"Invalid phone number format (prefix only) for CompanyProfile {poco.Id}."));
            }

           
            base.Verify(pocos);
        }

        if (exceptions.Count > 0)
        {
            throw new AggregateException(exceptions);
        }
    }

    private bool IsValidWebsite(string? website)
    {
       
        if (website != null)
        {
            string[] validExtensions = { ".ca", ".com", ".biz" };
            return validExtensions.Any(ext => website.EndsWith(ext, StringComparison.OrdinalIgnoreCase));
        }

        return false;
    }

  
    private bool IsValidPhoneNumber(string phoneNumber)
    {
        
        return phoneNumber != null && Regex.IsMatch(phoneNumber, @"^\d{3}-\d{3}-\d{4}$");
    }

}

