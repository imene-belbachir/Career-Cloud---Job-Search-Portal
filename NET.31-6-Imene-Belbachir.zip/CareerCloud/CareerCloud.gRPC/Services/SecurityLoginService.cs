﻿using CareerCloud.gRPC.Protos;
using Grpc.Core;
using System;
using System.Linq;
using Google.Protobuf.WellKnownTypes;
using Google.Protobuf;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;

using System.Net.Http;
using System.Threading.Tasks;

public class SecurityLoginService : SecurityLogin.SecurityLoginBase
{
    private readonly SecurityLoginLogic _logic;

    public SecurityLoginService(SecurityLoginLogic logic)
    {
        _logic = logic;
    }

    public override Task<SecurityLoginReply> GetSecurityLogin(SecurityLoginRequest request, ServerCallContext context)
    {
        try
        {
            var poco = _logic.Get(Guid.Parse(request.Id));
            if (poco == null)
            {
                throw new RpcException(new Status(StatusCode.NotFound, "Record not found"));
            }

            return Task.FromResult(ConvertToSecurityLoginReply(poco));
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<SecurityLoginList> GetAllSecurityLogin(Empty request, ServerCallContext context)
    {
        try
        {
            var list = new SecurityLoginList();
            list.SecurityLogins.AddRange(_logic.GetAll().Select(ConvertToSecurityLoginReply));
            return Task.FromResult(list);
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Emppt> CreateSecurityLogin(SecurityLoginList request, ServerCallContext context)
    {
        try
        {
            _logic.Add(request.SecurityLogins.Select(ConvertToSecurityLoginPoco).ToArray());
            return Task.FromResult(new Emppt());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Emppt> UpdateSecurityLogin(SecurityLoginList request, ServerCallContext context)
    {
        try
        {
            _logic.Update(request.SecurityLogins.Select(ConvertToSecurityLoginPoco).ToArray());
            return Task.FromResult(new Emppt());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Emppt> DeleteSecurityLogin(SecurityLoginList request, ServerCallContext context)
    {
        try
        {
            _logic.Delete(request.SecurityLogins.Select(ConvertToSecurityLoginPoco).ToArray());
            return Task.FromResult(new Emppt());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    private SecurityLoginReply ConvertToSecurityLoginReply(SecurityLoginPoco poco)
    {
        return new SecurityLoginReply
        {
            Id = poco.Id.ToString(),
            Login = poco.Login,
            Password = poco.Password,
            Created = Timestamp.FromDateTime(poco.Created),
            PasswordUpdate = poco.PasswordUpdate is DateTime dtPasswordUpdate ? Timestamp.FromDateTime(dtPasswordUpdate) : null,
            AgreementAccepted = poco.AgreementAccepted is DateTime dtAgreementAccepted ? Timestamp.FromDateTime(dtAgreementAccepted) : null,
            IsLocked = poco.IsLocked,
            IsInactive = poco.IsInactive,
            EmailAddress = poco.EmailAddress,
            PhoneNumber = poco.PhoneNumber,
            FullName = poco.FullName,
            ForceChangePassword = poco.ForceChangePassword,
            PreferredLanguage = poco.PrefferredLanguage,
            TimeStamp = ByteString.CopyFrom(poco.TimeStamp)
        };
    }

    private SecurityLoginPoco ConvertToSecurityLoginPoco(SecurityLoginReply reply)
    {
        return new SecurityLoginPoco
        {
            Id = Guid.Parse(reply.Id),
            Login = reply.Login,
            Password = reply.Password,
            Created = reply.Created.ToDateTime(),
            PasswordUpdate = reply.PasswordUpdate?.ToDateTime(),
            AgreementAccepted = reply.AgreementAccepted?.ToDateTime(),
            IsLocked = reply.IsLocked,
            IsInactive = reply.IsInactive,
            EmailAddress = reply.EmailAddress,
            PhoneNumber = reply.PhoneNumber,
            FullName = reply.FullName,
            ForceChangePassword = reply.ForceChangePassword,
            PrefferredLanguage = reply.PreferredLanguage,
            TimeStamp = reply.TimeStamp.ToByteArray()
        };
    }
}
