﻿using CareerCloud.gRPC;
using Grpc.Core;
using System;
using System.Linq;
using Google.Protobuf.WellKnownTypes;
using Google.Protobuf;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using CareerCloud.gRPC.Protos;
using System.Net.Http;



        public class ApplicantEducationService : ApplicantEducation.ApplicantEducationBase

          {
              private readonly ApplicantEducationLogic _logic;

              public ApplicantEducationService(ApplicantEducationLogic logic)
              {
                  _logic = logic;
              }

              public override Task<ApplicantEducationReply> GetApplicantEducation(ApplicantEducationRequest request, ServerCallContext context)
              {
                  try
                  {
                      var poco = _logic.Get(Guid.Parse(request.Id));
                      if (poco == null)
                      {
                          throw new RpcException(new Status(StatusCode.NotFound, "Record not found"));
                      }

                      return Task.FromResult(ConvertToApplicantEducationReply(poco));
                  }
                  catch (Exception ex)
                  {
                      throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
                  }
              }

              public override Task<ApplicantEducationList> GetAllApplicantEducation(Empty request, ServerCallContext context)
              {
                  try
                  {
                      var list = new ApplicantEducationList();
                      list.ApplicantEducations.AddRange(_logic.GetAll().Select(ConvertToApplicantEducationReply));
                      return Task.FromResult(list);
                  }
                  catch (Exception ex)
                  {
                      throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
                  }
              }

              public override Task<Emptty> CreateApplicantEducation(ApplicantEducationList request, ServerCallContext context)
              {
                  try
                  {
                      _logic.Add(request.ApplicantEducations.Select(ConvertToApplicantEducationPoco).ToArray());
                      return Task.FromResult(new Emptty());
                  }
                  catch (Exception ex)
                  {
                      throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
                  }
              }

              public override Task<Emptty> UpdateApplicantEducation(ApplicantEducationList request, ServerCallContext context)
              {
                  try
                  {
                      _logic.Update(request.ApplicantEducations.Select(ConvertToApplicantEducationPoco).ToArray());
                      return Task.FromResult(new Emptty());
                  }
                  catch (Exception ex)
                  {
                      throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
                  }
              }

              public override Task<Emptty> DeleteApplicantEducation(ApplicantEducationList request, ServerCallContext context)
              {
                  try
                  {
                      _logic.Delete(request.ApplicantEducations.Select(ConvertToApplicantEducationPoco).ToArray());
                      return Task.FromResult(new Emptty());
                  }
                  catch (Exception ex)
                  {
                      throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
                  }
              }

              private ApplicantEducationReply ConvertToApplicantEducationReply(ApplicantEducationPoco poco)
              {
                  return new ApplicantEducationReply
                  {
                      Id = poco.Id.ToString(),
                      Applicant = poco.Applicant.ToString(),
                      Major = poco.Major,
                      CertificateDiploma = poco.CertificateDiploma,
                      StartDate = Timestamp.FromDateTime(poco.StartDate ?? DateTime.MinValue),
                      CompletionDate = Timestamp.FromDateTime(poco.CompletionDate ?? DateTime.MinValue),
                      CompletionPercent = poco.CompletionPercent ?? 0,
                      TimeStamp = ByteString.CopyFrom(poco.TimeStamp)
                  };
              }

              private ApplicantEducationPoco ConvertToApplicantEducationPoco(ApplicantEducationReply reply)
              {
                  return new ApplicantEducationPoco
                  {
                      Id = Guid.Parse(reply.Id),
                      Applicant = Guid.Parse(reply.Applicant),
                      Major = reply.Major,
                      CertificateDiploma = reply.CertificateDiploma,
                      StartDate = reply.StartDate.ToDateTime(),
                      CompletionDate = reply.CompletionDate.ToDateTime(),
                      CompletionPercent = Convert.ToByte(reply.CompletionPercent),

                      TimeStamp = reply.TimeStamp.ToByteArray()
                  };
              }
          }

