﻿using CareerCloud.gRPC.Protos;
using Grpc.Core;
using System;
using System.Linq;
using Google.Protobuf.WellKnownTypes;
using Google.Protobuf;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using CareerCloud.gRPC.Protos;
using System.Net.Http;
using System.Threading.Tasks;

public class CompanyJobEducationService : CompanyJobEducation.CompanyJobEducationBase
{
    private readonly CompanyJobEducationLogic _logic;

    public CompanyJobEducationService(CompanyJobEducationLogic logic)
    {
        _logic = logic;
    }

    public override Task<CompanyJobEducationReply> GetCompanyJobEducation(CompanyJobEducationRequest request, ServerCallContext context)
    {
        try
        {
            var poco = _logic.Get(Guid.Parse(request.Id));
            if (poco == null)
            {
                throw new RpcException(new Status(StatusCode.NotFound, "Record not found"));
            }

            return Task.FromResult(ConvertToCompanyJobEducationReply(poco));
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<CompanyJobEducationList> GetAllCompanyJobEducation(Empty request, ServerCallContext context)
    {
        try
        {
            var list = new CompanyJobEducationList();
            list.CompanyJobEducations.AddRange(_logic.GetAll().Select(ConvertToCompanyJobEducationReply));
            return Task.FromResult(list);
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Empt> CreateCompanyJobEducation(CompanyJobEducationList request, ServerCallContext context)
    {
        try
        {
            _logic.Add(request.CompanyJobEducations.Select(ConvertToCompanyJobEducationPoco).ToArray());
            return Task.FromResult(new Empt());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Empt> UpdateCompanyJobEducation(CompanyJobEducationList request, ServerCallContext context)
    {
        try
        {
            _logic.Update(request.CompanyJobEducations.Select(ConvertToCompanyJobEducationPoco).ToArray());
            return Task.FromResult(new Empt());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Empt> DeleteCompanyJobEducation(CompanyJobEducationList request, ServerCallContext context)
    {
        try
        {
            _logic.Delete(request.CompanyJobEducations.Select(ConvertToCompanyJobEducationPoco).ToArray());
            return Task.FromResult(new Empt());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    private CompanyJobEducationReply ConvertToCompanyJobEducationReply(CompanyJobEducationPoco poco)
    {
        return new CompanyJobEducationReply
        {
            Id = poco.Id.ToString(),
            Job = poco.Job.ToString(),
            Major = poco.Major,
            Importance = poco.Importance,
            TimeStamp = ByteString.CopyFrom(poco.TimeStamp)
        };
    }

    private CompanyJobEducationPoco ConvertToCompanyJobEducationPoco(CompanyJobEducationReply reply)
    {
        return new CompanyJobEducationPoco
        {
            Id = Guid.Parse(reply.Id),
            Job = Guid.Parse(reply.Job),
            Major = reply.Major,
            Importance = (short)reply.Importance,
            TimeStamp = reply.TimeStamp.ToByteArray()
        };
    }
}
