﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.gRPC.Protos;
using CareerCloud.Pocos;
using Google.Protobuf.WellKnownTypes;
using Google.Protobuf;
using Grpc.Core;
namespace CareerCloud.gRPC.Services;

public class ApplicantJobApplicationService : ApplicantJobApplication.ApplicantJobApplicationBase
{
    private readonly ApplicantJobApplicationLogic _logic;

    public ApplicantJobApplicationService(ApplicantJobApplicationLogic logic)
    {
        _logic = logic;
    }

    public override Task<ApplicantJobApplicationReply> GetApplicantJobApplication(ApplicantJobApplicationRequest request, ServerCallContext context)
    {
        try
        {
            var poco = _logic.Get(Guid.Parse(request.Id));
            if (poco == null)
            {
                throw new RpcException(new Status(StatusCode.NotFound, "Record not found"));
            }

            return Task.FromResult(ConvertToApplicantJobApplicationReply(poco));
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<ApplicantJobApplicationList> GetAllApplicantJobApplication(Empty request, ServerCallContext context)
    {
        try
        {
            var list = new ApplicantJobApplicationList();
            list.ApplicantJobApplications.AddRange(_logic.GetAll().Select(ConvertToApplicantJobApplicationReply));
            return Task.FromResult(list);
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Empttyy> CreateApplicantJobApplication(ApplicantJobApplicationList request, ServerCallContext context)
    {
        try
        {
            _logic.Add(request.ApplicantJobApplications.Select(ConvertToApplicantJobApplicationPoco).ToArray());
            return Task.FromResult(new Empttyy());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Empttyy> UpdateApplicantJobApplication(ApplicantJobApplicationList request, ServerCallContext context)
    {
        try
        {
            _logic.Update(request.ApplicantJobApplications.Select(ConvertToApplicantJobApplicationPoco).ToArray());
            return Task.FromResult(new Empttyy());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Empttyy> DeleteApplicantJobApplication(ApplicantJobApplicationList request, ServerCallContext context)
    {
        try
        {
            _logic.Delete(request.ApplicantJobApplications.Select(ConvertToApplicantJobApplicationPoco).ToArray());
            return Task.FromResult(new Empttyy());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    private ApplicantJobApplicationReply ConvertToApplicantJobApplicationReply(ApplicantJobApplicationPoco poco)
    {
        return new ApplicantJobApplicationReply
        {
            Id = poco.Id.ToString(),
            Applicant = poco.Applicant.ToString(),
            Job = poco.Job.ToString(),
            ApplicationDate = Timestamp.FromDateTime(poco.ApplicationDate),
            TimeStamp = Google.Protobuf.WellKnownTypes.Timestamp.Parser.ParseFrom(poco.TimeStamp),
        };
    }

    private ApplicantJobApplicationPoco ConvertToApplicantJobApplicationPoco(ApplicantJobApplicationReply reply)
    {
        return new ApplicantJobApplicationPoco
        {
            Id = Guid.Parse(reply.Id),
            Applicant = Guid.Parse(reply.Applicant),
            Job = Guid.Parse(reply.Job),
            ApplicationDate = reply.ApplicationDate.ToDateTime(),
            TimeStamp = reply.TimeStamp.ToByteArray(),
        };
    }
}
