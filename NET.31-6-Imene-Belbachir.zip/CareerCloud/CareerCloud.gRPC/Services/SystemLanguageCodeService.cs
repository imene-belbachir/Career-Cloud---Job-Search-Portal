﻿using CareerCloud.gRPC.Protos;
using Grpc.Core;
using System;
using System.Linq;
using Google.Protobuf.WellKnownTypes;
using Google.Protobuf;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using CareerCloud.gRPC.Protos;
using System.Net.Http;
using System.Threading.Tasks;

public class SystemLanguageCodeService : SystemLanguageCode.SystemLanguageCodeBase
{
    private readonly SystemLanguageCodeLogic _logic;

    public SystemLanguageCodeService(SystemLanguageCodeLogic logic)
    {
        _logic = logic;
    }

    public override Task<SystemLanguageCodeReply> GetSystemLanguageCode(SystemLanguageCodeRequest request, ServerCallContext context)
    {
        try
        {
            var poco = _logic.Get(Guid.Parse(request.LanguageID));

            // var poco = _logic.Get(request.LanguageID);
            if (poco == null)
            {
                throw new RpcException(new Status(StatusCode.NotFound, "Record not found"));
            }

            return Task.FromResult(ConvertToSystemLanguageCodeReply(poco));
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<SystemLanguageCodeList> GetAllSystemLanguageCode(Empty request, ServerCallContext context)
    {
        try
        {
            var list = new SystemLanguageCodeList();
            list.SystemLanguageCodes.AddRange(_logic.GetAll().Select(ConvertToSystemLanguageCodeReply));
            return Task.FromResult(list);
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Emmppt> CreateSystemLanguageCode(SystemLanguageCodeList request, ServerCallContext context)
    {
        try
        {
            _logic.Add(request.SystemLanguageCodes.Select(ConvertToSystemLanguageCodePoco).ToArray());
            return Task.FromResult(new Emmppt());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Emmppt> UpdateSystemLanguageCode(SystemLanguageCodeList request, ServerCallContext context)
    {
        try
        {
            _logic.Update(request.SystemLanguageCodes.Select(ConvertToSystemLanguageCodePoco).ToArray());
            return Task.FromResult(new Emmppt());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Emmppt> DeleteSystemLanguageCode(SystemLanguageCodeList request, ServerCallContext context)
    {
        try
        {
            _logic.Delete(request.SystemLanguageCodes.Select(ConvertToSystemLanguageCodePoco).ToArray());
            return Task.FromResult(new Emmppt());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    private SystemLanguageCodeReply ConvertToSystemLanguageCodeReply(SystemLanguageCodePoco poco)
    {
        return new SystemLanguageCodeReply
        {
            LanguageID = poco.LanguageID,
            Name = poco.Name,
            NativeName = poco.NativeName
        };
    }

    private SystemLanguageCodePoco ConvertToSystemLanguageCodePoco(SystemLanguageCodeReply reply)
    {
        return new SystemLanguageCodePoco
        {
            LanguageID = reply.LanguageID,
            Name = reply.Name,
            NativeName = reply.NativeName
        };
    }
}
