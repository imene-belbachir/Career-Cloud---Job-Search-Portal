﻿
using Grpc.Core;
using System;
using System.Linq;
using Google.Protobuf.WellKnownTypes;
using Google.Protobuf;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using CareerCloud.gRPC.Protos;
public class CompanyJobService : CompanyJob.CompanyJobBase
{
    private readonly CompanyJobLogic _logic;

    public CompanyJobService(CompanyJobLogic logic)
    {
        _logic = logic;
    }

    public override Task<CompanyJobReply> GetCompanyJob(CompanyJobRequest request, ServerCallContext context)
    {
        try
        {
            var poco = _logic.Get(Guid.Parse(request.Id));
            if (poco == null)
            {
                throw new RpcException(new Status(StatusCode.NotFound, "Record not found"));
            }

            return Task.FromResult(ConvertToCompanyJobReply(poco));
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<CompanyJobList> GetAllCompanyJob(Empty request, ServerCallContext context)
    {
        try
        {
            var list = new CompanyJobList();
            list.CompanyJobs.AddRange(_logic.GetAll().Select(ConvertToCompanyJobReply));
            return Task.FromResult(list);
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Emptt> CreateCompanyJob(CompanyJobList request, ServerCallContext context)
    {
        try
        {
            _logic.Add(request.CompanyJobs.Select(ConvertToCompanyJobPoco).ToArray());
            return Task.FromResult(new Emptt());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Emptt> UpdateCompanyJob(CompanyJobList request, ServerCallContext context)
    {
        try
        {
            _logic.Update(request.CompanyJobs.Select(ConvertToCompanyJobPoco).ToArray());
            return Task.FromResult(new Emptt());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Emptt> DeleteCompanyJob(CompanyJobList request, ServerCallContext context)
    {
        try
        {
            _logic.Delete(request.CompanyJobs.Select(ConvertToCompanyJobPoco).ToArray());
            return Task.FromResult(new Emptt());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    private CompanyJobReply ConvertToCompanyJobReply(CompanyJobPoco poco)
    {
        return new CompanyJobReply
        {
            Id = poco.Id.ToString(),
            Company = poco.Company.ToString(),
            ProfileCreated = Timestamp.FromDateTime(poco.ProfileCreated),
            IsInactive = poco.IsInactive,
            IsCompanyHidden = poco.IsCompanyHidden,
            TimeStamp = ByteString.CopyFrom(poco.TimeStamp ?? Array.Empty<byte>())
        };
    }

    private CompanyJobPoco ConvertToCompanyJobPoco(CompanyJobReply reply)
    {
        return new CompanyJobPoco
        {
            Id = Guid.Parse(reply.Id),
            Company = Guid.Parse(reply.Company),
            ProfileCreated = reply.ProfileCreated.ToDateTime(),
            IsInactive = reply.IsInactive,
            IsCompanyHidden = reply.IsCompanyHidden,
            TimeStamp = reply.TimeStamp?.ToByteArray()
        };
    }
}

