﻿// CompanyDescriptionService.cs

using CareerCloud.gRPC.Protos;
using Grpc.Core;
using System;
using System.Linq;
using Google.Protobuf.WellKnownTypes;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Google.Protobuf;
using System.Text;

namespace CareerCloud.gRPC.Services
{
    public class CompanyDescriptionService : CompanyDescription.CompanyDescriptionBase
    {
        private readonly CompanyDescriptionLogic _logic;

        public CompanyDescriptionService(CompanyDescriptionLogic logic)
        {
            _logic = logic;
        }

        public override Task<CompanyDescriptionReply> GetCompanyDescription(CompanyDescriptionRequest request, ServerCallContext context)
        {
            try
            {
                var poco = _logic.Get(Guid.Parse(request.Id));
                if (poco == null)
                {
                    throw new RpcException(new Status(StatusCode.NotFound, "Record not found"));
                }

                return Task.FromResult(ConvertToCompanyDescriptionReply(poco));
            }
            catch (Exception ex)
            {
                throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
            }
        }

        public override Task<CompanyDescriptionList> GetAllCompanyDescription(Empty request, ServerCallContext context)
        {
            try
            {
                var list = new CompanyDescriptionList();
                list.CompanyDescriptions.AddRange(_logic.GetAll().Select(ConvertToCompanyDescriptionReply));
                return Task.FromResult(list);
            }
            catch (Exception ex)
            {
                throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
            }
        }

        public override Task<Emptyyy> CreateCompanyDescription(CompanyDescriptionList request, ServerCallContext context)
        {
            try
            {
                _logic.Add(request.CompanyDescriptions.Select(ConvertToCompanyDescriptionPoco).ToArray());
                return Task.FromResult(new Emptyyy());
            }
            catch (Exception ex)
            {
                throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
            }
        }

        public override Task<Emptyyy> UpdateCompanyDescription(CompanyDescriptionList request, ServerCallContext context)
        {
            try
            {
                _logic.Update(request.CompanyDescriptions.Select(ConvertToCompanyDescriptionPoco).ToArray());
                return Task.FromResult(new Emptyyy());
            }
            catch (Exception ex)
            {
                throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
            }
        }

        public override Task<Emptyyy> DeleteCompanyDescription(CompanyDescriptionList request, ServerCallContext context)
        {
            try
            {
                _logic.Delete(request.CompanyDescriptions.Select(ConvertToCompanyDescriptionPoco).ToArray());
                return Task.FromResult(new Emptyyy());
            }
            catch (Exception ex)
            {
                throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
            }
        }

        private CompanyDescriptionReply ConvertToCompanyDescriptionReply(CompanyDescriptionPoco poco)
        {
            return new CompanyDescriptionReply
            {
                Id = poco.Id.ToString(),
                Company = poco.Company.ToString(),
                LanguageId = poco.LanguageId,
                CompanyName = poco.CompanyName,
                CompanyDescription = poco.CompanyDescription,
                TimeStamp = poco.TimeStamp != null
    ? Google.Protobuf.WellKnownTypes.Timestamp.FromDateTime(DateTime.SpecifyKind(DateTime.Parse(Encoding.UTF8.GetString(poco.TimeStamp)), DateTimeKind.Utc))
    : null

                //  TimeStamp = poco.TimeStamp != null ? Timestamp.FromDateTime(poco.TimeStamp.ToDateTime()) : null
            };
        }

        private CompanyDescriptionPoco ConvertToCompanyDescriptionPoco(CompanyDescriptionReply reply)
        {
            return new CompanyDescriptionPoco
            {
                Id = Guid.Parse(reply.Id),
                Company = Guid.Parse(reply.Company),
                LanguageId = reply.LanguageId,
                CompanyName = reply.CompanyName,
                CompanyDescription = reply.CompanyDescription,
                TimeStamp = reply.TimeStamp?.ToByteArray()
            };
        }
    }
}
