﻿using CareerCloud.gRPC;
using Grpc.Core;
using System;
using System.Linq;
using Google.Protobuf.WellKnownTypes;
using Google.Protobuf;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using CareerCloud.gRPC.Protos;
using System.Net.Http;

public class ApplicantProfileService : ApplicantProfile.ApplicantProfileBase
{
    private readonly ApplicantProfileLogic _logic;

    public ApplicantProfileService(ApplicantProfileLogic logic)
    {
        _logic = logic;
    }

    public override Task<ApplicantProfileReply> GetApplicantProfile(ApplicantProfileRequest request, ServerCallContext context)
    {
        try
        {
            var poco = _logic.Get(Guid.Parse(request.Id));
            if (poco == null)
            {
                throw new RpcException(new Status(StatusCode.NotFound, "Record not found"));
            }

            return Task.FromResult(ConvertToApplicantProfileReply(poco));
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<ApplicantProfileList> GetAllApplicantProfiles(Empty request, ServerCallContext context)
    {
        try
        {
            var list = new ApplicantProfileList();
            list.ApplicantProfiles.AddRange(_logic.GetAll().Select(ConvertToApplicantProfileReply));
            return Task.FromResult(list);
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Emptyy> CreateApplicantProfile(ApplicantProfileList request, ServerCallContext context)
    {
        try
        {
            _logic.Add(request.ApplicantProfiles.Select(ConvertToApplicantProfilePoco).ToArray());
            return Task.FromResult(new Emptyy());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Emptyy> UpdateApplicantProfile(ApplicantProfileList request, ServerCallContext context)
    {
        try
        {
            _logic.Update(request.ApplicantProfiles.Select(ConvertToApplicantProfilePoco).ToArray());
            return Task.FromResult(new Emptyy());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    public override Task<Emptyy> DeleteApplicantProfile(ApplicantProfileList request, ServerCallContext context)
    {
        try
        {
            _logic.Delete(request.ApplicantProfiles.Select(ConvertToApplicantProfilePoco).ToArray());
            return Task.FromResult(new Emptyy());
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, $"Error: {ex.Message}"));
        }
    }

    private ApplicantProfileReply ConvertToApplicantProfileReply(ApplicantProfilePoco poco)
    {
        return new ApplicantProfileReply
        {
            Id = poco.Id.ToString(),
            Login = poco.Login.ToString(),
            CurrentSalary = (double)poco.CurrentSalary,
            CurrentRate = (double)poco.CurrentRate,
            Currency = poco.Currency,
            Country = poco.Country,
            Province = poco.Province,
            Street = poco.Street,
            City = poco.City,
            PostalCode = poco.PostalCode,
            TimeStamp = Timestamp.FromDateTime(Convert.ToDateTime(poco.TimeStamp))
        };
    }

    private ApplicantProfilePoco ConvertToApplicantProfilePoco(ApplicantProfileReply reply)
    {
        return new ApplicantProfilePoco
        {
            Id = Guid.Parse(reply.Id),
            Login = Guid.Parse(reply.Login),
            CurrentSalary = (decimal)reply.CurrentSalary,
            CurrentRate = (decimal)reply.CurrentRate,
            Currency = reply.Currency,
            Country = reply.Country,
            Province = reply.Province,
            Street = reply.Street,
            City = reply.City,
            PostalCode = reply.PostalCode,
            TimeStamp = reply.TimeStamp.ToByteArray()
        };
    }
}
